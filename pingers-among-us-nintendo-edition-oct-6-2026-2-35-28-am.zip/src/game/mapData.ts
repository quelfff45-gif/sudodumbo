import { RoomId, Vent, TaskDefinition } from '../types';

export interface RoomRect {
  id: RoomId;
  name: string;
  x: number;
  y: number;
  w: number;
  h: number;
  color: string;
}

export interface Wall {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface CameraZone {
  id: string;
  name: string;
  room: RoomId;
  x: number;
  y: number;
  w: number;
  h: number;
}

export const MAP_WIDTH = 2200;
export const MAP_HEIGHT = 1500;

export const ROOMS: RoomRect[] = [
  { id: 'cafeteria', name: 'CAFETERIA', x: 880, y: 150, w: 440, h: 320, color: '#334155' },
  { id: 'weapons', name: 'WEAPONS', x: 1450, y: 160, w: 320, h: 260, color: '#1e293b' },
  { id: 'navigation', name: 'NAVIGATION (SONAR)', x: 1720, y: 560, w: 320, h: 320, color: '#0f172a' },
  { id: 'shields', name: 'SHIELDS', x: 1460, y: 980, w: 320, h: 260, color: '#1e293b' },
  { id: 'communications', name: 'COMMS', x: 1220, y: 1040, w: 220, h: 200, color: '#1e293b' },
  { id: 'storage', name: 'STORAGE', x: 880, y: 920, w: 320, h: 340, color: '#1e293b' },
  { id: 'admin', name: 'ADMIN', x: 1240, y: 580, w: 280, h: 260, color: '#1e293b' },
  { id: 'electrical', name: 'ELECTRICAL', x: 540, y: 840, w: 300, h: 300, color: '#1e293b' },
  { id: 'medbay', name: 'MEDBAY', x: 580, y: 460, w: 260, h: 260, color: '#1e293b' },
  { id: 'security', name: 'SECURITY (CCTV)', x: 340, y: 540, w: 220, h: 260, color: '#1e293b' },
  { id: 'reactor', name: 'REACTOR', x: 100, y: 440, w: 220, h: 480, color: '#0f172a' },
];

// Corridors connecting the rooms
export const CORRIDORS: Wall[] = [
  // Cafeteria to Weapons
  { x: 1300, y: 240, w: 160, h: 100 },
  // Cafeteria to Admin/Storage down
  { x: 1030, y: 460, w: 120, h: 470 },
  // Cafeteria to MedBay
  { x: 780, y: 320, w: 120, h: 150 },
  // Admin to Navigation
  { x: 1510, y: 680, w: 220, h: 100 },
  // Weapons to Navigation
  { x: 1580, y: 410, w: 100, h: 180 },
  // Navigation to Shields
  { x: 1620, y: 860, w: 100, h: 140 },
  // Storage to Shields
  { x: 1190, y: 1080, w: 280, h: 90 },
  // Storage to Electrical
  { x: 830, y: 980, w: 70, h: 100 },
  // Electrical to Security / Medbay corridor
  { x: 420, y: 780, w: 140, h: 90 },
  // Security to Reactor top and bottom
  { x: 280, y: 520, w: 80, h: 80 },
  { x: 280, y: 740, w: 80, h: 80 },
];

export const VENTS: Vent[] = [
  { id: 'vent_cafeteria', room: 'cafeteria', x: 1240, y: 220, connectedVentIds: ['vent_admin', 'vent_hallway_east'] },
  { id: 'vent_admin', room: 'admin', x: 1440, y: 640, connectedVentIds: ['vent_cafeteria', 'vent_hallway_east'] },
  { id: 'vent_hallway_east', room: 'corridor' as unknown as RoomId, x: 1600, y: 720, connectedVentIds: ['vent_cafeteria', 'vent_admin'] },

  { id: 'vent_electrical', room: 'electrical', x: 590, y: 890, connectedVentIds: ['vent_medbay', 'vent_security'] },
  { id: 'vent_medbay', room: 'medbay', x: 630, y: 510, connectedVentIds: ['vent_electrical', 'vent_security'] },
  { id: 'vent_security', room: 'security', x: 390, y: 580, connectedVentIds: ['vent_electrical', 'vent_medbay'] },

  { id: 'vent_weapons', room: 'weapons', x: 1700, y: 220, connectedVentIds: ['vent_nav', 'vent_shields'] },
  { id: 'vent_nav', room: 'navigation', x: 1980, y: 620, connectedVentIds: ['vent_weapons', 'vent_shields'] },
  { id: 'vent_shields', room: 'shields', x: 1700, y: 1160, connectedVentIds: ['vent_weapons', 'vent_nav'] },

  { id: 'vent_reactor_top', room: 'reactor', x: 150, y: 490, connectedVentIds: ['vent_reactor_bot'] },
  { id: 'vent_reactor_bot', room: 'reactor', x: 150, y: 860, connectedVentIds: ['vent_reactor_top'] },
];

export const EMERGENCY_BUTTON = {
  x: 1100,
  y: 310,
  radius: 35,
};

export const SECURITY_CAMERAS: CameraZone[] = [
  { id: 'cam_cafe', name: 'CAM 01: CAFETERIA HUB', room: 'cafeteria', x: 920, y: 180, w: 360, h: 260 },
  { id: 'cam_nav', name: 'CAM 02: NAVIGATION RADAR', room: 'navigation', x: 1740, y: 580, w: 280, h: 280 },
  { id: 'cam_elec', name: 'CAM 03: ELEC CORRIDOR', room: 'electrical', x: 560, y: 860, w: 260, h: 250 },
  { id: 'cam_admin', name: 'CAM 04: ADMIN DESK', room: 'admin', x: 1260, y: 600, w: 240, h: 220 },
];

export const TASK_TEMPLATES: Omit<TaskDefinition, 'id' | 'completed'>[] = [
  {
    type: 'sonar_pinger',
    name: 'Calibrate Sonar Pinger',
    room: 'navigation',
    x: 1880,
    y: 720,
  },
  {
    type: 'fix_wiring',
    name: 'Fix Electrical Wiring',
    room: 'electrical',
    x: 640,
    y: 950,
  },
  {
    type: 'swipe_card',
    name: 'Admin Card Swipe',
    room: 'admin',
    x: 1380,
    y: 690,
  },
  {
    type: 'clear_asteroids',
    name: 'Clear Asteroids (Weapons)',
    room: 'weapons',
    x: 1610,
    y: 280,
  },
  {
    type: 'medbay_scan',
    name: 'Submit MedBay Scan',
    room: 'medbay',
    x: 710,
    y: 590,
  },
  {
    type: 'divert_power',
    name: 'Divert Power to Shields',
    room: 'shields',
    x: 1620,
    y: 1110,
  },
];

/**
 * Checks if a point (x, y) is inside the playable walk mesh
 */
export function isInsideShip(x: number, y: number): boolean {
  // Margin
  const m = 18;
  // Check rooms
  for (const r of ROOMS) {
    if (x >= r.x + m && x <= r.x + r.w - m && y >= r.y + m && y <= r.y + r.h - m) {
      return true;
    }
  }
  // Check corridors
  for (const c of CORRIDORS) {
    if (x >= c.x && x <= c.x + c.w && y >= c.y && y <= c.y + c.h) {
      return true;
    }
  }
  return false;
}

/**
 * Returns which room a point is in
 */
export function getRoomAt(x: number, y: number): RoomId {
  for (const r of ROOMS) {
    if (x >= r.x && x <= r.x + r.w && y >= r.y && y <= r.y + r.h) {
      return r.id;
    }
  }
  return 'hallway';
}
