import React from 'react';
import { Role, BeanColor, HatType } from '../types';
import { sound } from '../audio/soundEngine';
import { Play, Sparkles, User, Shield, Skull, Radio } from 'lucide-react';

interface NintendoTitleScreenProps {
  onStartGame: (role?: Role) => void;
  onOpenCustomizer: () => void;
  onOpenWorkspace?: () => void;
  onOpenCredits?: () => void;
  playerColor: BeanColor;
  playerHat: HatType;
  playerName: string;
}

const COLOR_MAP: Record<BeanColor, string> = {
  red: '#ef4444',
  blue: '#3b82f6',
  green: '#22c55e',
  pink: '#ec4899',
  orange: '#f97316',
  yellow: '#eab308',
  black: '#475569',
  white: '#f8fafc',
  purple: '#a855f7',
  cyan: '#06b6d4',
};

export const NintendoTitleScreen: React.FC<NintendoTitleScreenProps> = ({
  onStartGame,
  onOpenCustomizer,
  onOpenWorkspace,
  onOpenCredits,
  playerColor,
  playerHat,
  playerName,
}) => {
  return (
    <div className="relative w-full h-full bg-zinc-950 text-zinc-100 font-arcade flex flex-col items-center justify-between p-6 overflow-hidden">
      {/* Starfield parallax backdrop */}
      <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:28px_28px] opacity-30" />

      {/* Top Nintendo & Roman James Productions Badges */}
      <div className="z-10 flex items-center justify-between w-full max-w-2xl px-2">
        <div className="flex items-center gap-2 border-2 border-red-600 px-3 py-1 rounded bg-black/60 shadow">
          <span className="w-2.5 h-2.5 rounded-full bg-red-600 animate-ping" />
          <span className="text-red-500 text-xs font-bold tracking-widest">Nintendo</span>
        </div>

        <div className="border border-amber-500/80 rounded-full px-3 py-1 bg-amber-950/50 text-[9px] text-amber-300 flex items-center gap-1.5 shadow">
          <Sparkles size={11} className="text-amber-400" />
          <span className="font-pixel tracking-wider">ROMAN JAMES PRODUCTIONS</span>
        </div>
      </div>

      {/* Center Game Title & Floating Beans */}
      <div className="z-10 flex flex-col items-center gap-4 my-auto">
        {/* Animated Crewmate Sprite */}
        <div className="relative my-2 animate-bounce">
          <div
            className="w-16 h-22 rounded-t-full rounded-b-xl border-4 border-black shadow-2xl relative"
            style={{ backgroundColor: COLOR_MAP[playerColor] }}
          >
            {/* Visor */}
            <div className="absolute top-4 left-2.5 w-10 h-5 bg-cyan-200 border-2 border-black rounded-full" />
            {/* Backpack */}
            <div
              className="absolute top-5 -left-3.5 w-3.5 h-11 rounded border-2 border-black"
              style={{ backgroundColor: COLOR_MAP[playerColor] }}
            />
          </div>
        </div>

        {/* Title Lockup */}
        <div className="text-center">
          <div className="text-[9px] sm:text-[10px] text-amber-400 tracking-[0.25em] font-pixel mb-1.5 animate-pulse">
            ROMAN JAMES PRODUCTIONS PRESENTS
          </div>
          <h1 className="text-2xl sm:text-4xl text-amber-400 tracking-wider drop-shadow-[0_4px_12px_rgba(245,158,11,0.5)]">
            PINGERS
          </h1>
          <div className="text-base sm:text-2xl text-red-500 tracking-widest mt-1 drop-shadow-[0_2px_8px_rgba(239,68,68,0.7)]">
            AMONG US
          </div>
          <div className="text-[9px] sm:text-[10px] text-zinc-400 mt-2 font-pixel tracking-normal">
            NINTENDO HARDWARE EDITION · RETRO SPACE ODYSSEY
          </div>
        </div>

        {/* Mission Select Buttons */}
        <div className="flex flex-col gap-2.5 w-full max-w-xs mt-4">
          {/* Play as Crewmate */}
          <button
            onClick={() => onStartGame('crewmate')}
            className="flex items-center justify-between px-4 py-3 bg-emerald-700 hover:bg-emerald-600 text-white rounded-lg border-b-4 border-emerald-950 transition-all text-[11px] cursor-pointer shadow-lg active:scale-98"
          >
            <div className="flex items-center gap-2">
              <Shield size={16} />
              <span>PLAY CREWMATE</span>
            </div>
            <span className="text-[9px] text-emerald-200">[TASKS]</span>
          </button>

          {/* Play as Impostor */}
          <button
            onClick={() => onStartGame('impostor')}
            className="flex items-center justify-between px-4 py-3 bg-red-700 hover:bg-red-600 text-white rounded-lg border-b-4 border-red-950 transition-all text-[11px] cursor-pointer shadow-lg active:scale-98"
          >
            <div className="flex items-center gap-2">
              <Skull size={16} />
              <span>PLAY IMPOSTOR</span>
            </div>
            <span className="text-[9px] text-red-200">[SABOTAGE]</span>
          </button>

          {/* Random Assignment */}
          <button
            onClick={() => onStartGame()}
            className="flex items-center justify-between px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg border-b-4 border-zinc-950 transition-all text-[10px] cursor-pointer shadow active:scale-98"
          >
            <div className="flex items-center gap-2">
              <Radio size={14} className="text-amber-400" />
              <span>RANDOM ROLE (NORMAL)</span>
            </div>
            <span>[A]</span>
          </button>

          <div className="grid grid-cols-2 gap-2 mt-1">
            {/* Customize Wardrobe */}
            <button
              onClick={onOpenCustomizer}
              className="flex items-center justify-center gap-1.5 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded border border-zinc-700 transition-all text-[9px] cursor-pointer"
            >
              <Sparkles size={12} className="text-amber-400" />
              <span>CUSTOMIZE</span>
            </button>

            {/* Producer Credits */}
            {onOpenCredits && (
              <button
                onClick={onOpenCredits}
                className="flex items-center justify-center gap-1.5 px-3 py-2 bg-amber-950/50 hover:bg-amber-900 text-amber-300 rounded border border-amber-500/50 transition-all text-[9px] cursor-pointer"
              >
                <span>CREDITS</span>
              </button>
            )}
          </div>

          {/* Comms Relay (Gmail & Forms) */}
          {onOpenWorkspace && (
            <button
              onClick={onOpenWorkspace}
              className="flex items-center justify-center gap-2 px-4 py-2.5 bg-amber-950/70 hover:bg-amber-900/90 text-amber-300 rounded border border-amber-500/60 transition-all text-[10px] cursor-pointer shadow-md"
            >
              <Radio size={14} className="text-amber-400 animate-pulse" />
              <span>COMMS RELAY (GMAIL &amp; FORMS)</span>
            </button>
          )}
        </div>
      </div>

      {/* Bottom Info Bar & Copyright */}
      <div className="z-10 flex flex-col items-center gap-1 text-[8px] text-zinc-500 text-center font-pixel">
        <div>CONTROLS: WASD / D-PAD TO MOVE · [A] / E INTERACT · [X] / R REPORT · [B] / V VENT · [Y] / Q KILL</div>
        <div className="text-amber-400/80 tracking-wider">© 2026 ROMAN JAMES PRODUCTIONS · ALL RIGHTS RESERVED</div>
      </div>
    </div>
  );
};

/**
 * Dramatic Role Reveal Screen
 */
export const RoleRevealScreen: React.FC<{
  role: Role;
  color: BeanColor;
}> = ({ role, color }) => {
  const isImpostor = role === 'impostor';

  return (
    <div className="relative w-full h-full bg-black text-zinc-100 font-arcade flex flex-col items-center justify-center p-6 overflow-hidden">
      {/* Red flash if impostor */}
      {isImpostor && (
        <div className="absolute inset-0 bg-red-950/40 animate-pulse pointer-events-none" />
      )}

      {/* Shhhh / Suspense icon */}
      <div className="relative mb-8 animate-bounce">
        <div
          className="w-20 h-28 rounded-t-full rounded-b-xl border-4 border-black shadow-2xl relative"
          style={{ backgroundColor: COLOR_MAP[color] }}
        >
          {/* Visor */}
          <div className="absolute top-5 left-3 w-12 h-6 bg-cyan-200 border-2 border-black rounded-full" />
          {/* Backpack */}
          <div
            className="absolute top-6 -left-3.5 w-4 h-14 rounded border-2 border-black"
            style={{ backgroundColor: COLOR_MAP[color] }}
          />
        </div>
      </div>

      <div className="text-center z-10">
        <h2
          className={`text-2xl sm:text-4xl tracking-widest ${
            isImpostor ? 'text-red-500 drop-shadow-[0_0_15px_#ef4444]' : 'text-cyan-400 drop-shadow-[0_0_15px_#22d3ee]'
          }`}
        >
          {isImpostor ? 'IMPOSTOR' : 'CREWMATE'}
        </h2>

        <p className="font-pixel text-xs sm:text-sm text-zinc-300 mt-4 max-w-md">
          {isImpostor
            ? 'Sabotage ship systems, vent stealthily, and eliminate the crewmates.'
            : 'Complete your assigned ship tasks and uncover the Impostor!'}
        </p>

        <div className="font-lcd text-lg text-zinc-500 mt-6 tracking-widest animate-pulse">
          PREPARING FLIGHT DECK...
        </div>
      </div>
    </div>
  );
};
