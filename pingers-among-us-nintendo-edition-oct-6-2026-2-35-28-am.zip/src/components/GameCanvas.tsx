import React, { useRef, useEffect } from 'react';
import {
  Character,
  DeadBody,
  TaskDefinition,
  Vent,
  SabotageState,
  BeanColor,
  HatType,
} from '../types';
import {
  ROOMS,
  CORRIDORS,
  VENTS,
  EMERGENCY_BUTTON,
  MAP_WIDTH,
  MAP_HEIGHT,
} from '../game/mapData';

interface GameCanvasProps {
  player: Character;
  characters: Character[];
  deadBodies: DeadBody[];
  tasks: TaskDefinition[];
  sabotage: SabotageState;
  nearbyTask: TaskDefinition | null;
  nearbyVent: Vent | null;
  nearbyBody: DeadBody | null;
  canEmergency: boolean;
  canAccessComms?: boolean;
  onCanvasClick?: (worldX: number, worldY: number) => void;
}

const COLOR_MAP: Record<BeanColor, { body: string; shadow: string }> = {
  red: { body: '#ef4444', shadow: '#991b1b' },
  blue: { body: '#3b82f6', shadow: '#1e40af' },
  green: { body: '#22c55e', shadow: '#166534' },
  pink: { body: '#ec4899', shadow: '#9d174d' },
  orange: { body: '#f97316', shadow: '#9a3412' },
  yellow: { body: '#eab308', shadow: '#854d0e' },
  black: { body: '#475569', shadow: '#1e293b' },
  white: { body: '#e2e8f0', shadow: '#94a3b8' },
  purple: { body: '#a855f7', shadow: '#6b21a8' },
  cyan: { body: '#06b6d4', shadow: '#0e7490' },
};

export const GameCanvas: React.FC<GameCanvasProps> = ({
  player,
  characters,
  deadBodies,
  tasks,
  sabotage,
  nearbyTask,
  nearbyVent,
  nearbyBody,
  canEmergency,
  canAccessComms,
  onCanvasClick,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let tick = 0;

    const render = () => {
      tick++;
      // Resize to match display
      const rect = canvas.getBoundingClientRect();
      if (canvas.width !== rect.width || canvas.height !== rect.height) {
        canvas.width = rect.width;
        canvas.height = rect.height;
      }

      const viewW = canvas.width;
      const viewH = canvas.height;

      // Camera center on player
      const camX = player.x - viewW / 2;
      const camY = player.y - viewH / 2;

      ctx.save();
      // Clear background with deep space
      ctx.fillStyle = '#05070f';
      ctx.fillRect(0, 0, viewW, viewH);

      // Starfield parallax
      ctx.save();
      ctx.fillStyle = '#ffffff';
      for (let i = 0; i < 45; i++) {
        const starX = ((i * 137.5 - camX * 0.2) % viewW + viewW) % viewW;
        const starY = ((i * 223.7 - camY * 0.2) % viewH + viewH) % viewH;
        const radius = (i % 3 === 0) ? 1.5 : 1;
        ctx.beginPath();
        ctx.arc(starX, starY, radius, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Transform camera
      ctx.translate(-camX, -camY);

      // 1. Draw Corridors
      ctx.fillStyle = '#1e293b';
      for (const c of CORRIDORS) {
        ctx.fillRect(c.x, c.y, c.w, c.h);
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 4;
        ctx.strokeRect(c.x, c.y, c.w, c.h);
      }

      // 2. Draw Rooms
      for (const r of ROOMS) {
        // Floor tile
        ctx.fillStyle = r.id === 'cafeteria' ? '#273449' : r.color;
        ctx.fillRect(r.x, r.y, r.w, r.h);

        // Floor grid
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
        ctx.lineWidth = 2;
        const step = 40;
        for (let gx = r.x; gx <= r.x + r.w; gx += step) {
          ctx.beginPath();
          ctx.moveTo(gx, r.y);
          ctx.lineTo(gx, r.y + r.h);
          ctx.stroke();
        }
        for (let gy = r.y; gy <= r.y + r.h; gy += step) {
          ctx.beginPath();
          ctx.moveTo(r.x, gy);
          ctx.lineTo(r.x + r.w, gy);
          ctx.stroke();
        }

        // Room Wall Border
        ctx.strokeStyle = '#475569';
        ctx.lineWidth = 6;
        ctx.strokeRect(r.x, r.y, r.w, r.h);

        // Room Title
        ctx.font = 'bold 12px "Press Start 2P", monospace';
        ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.textAlign = 'center';
        ctx.fillText(r.name, r.x + r.w / 2, r.y + 35);
      }

      // 3. Draw Emergency Button in Cafeteria
      ctx.save();
      ctx.beginPath();
      ctx.arc(EMERGENCY_BUTTON.x, EMERGENCY_BUTTON.y, EMERGENCY_BUTTON.radius, 0, Math.PI * 2);
      ctx.fillStyle = '#1e293b';
      ctx.fill();
      ctx.strokeStyle = '#ef4444';
      ctx.lineWidth = 4;
      ctx.stroke();

      // Glass dome
      ctx.beginPath();
      ctx.arc(EMERGENCY_BUTTON.x, EMERGENCY_BUTTON.y, 20, 0, Math.PI * 2);
      ctx.fillStyle = canEmergency ? '#ef4444' : '#7f1d1d';
      ctx.fill();

      // Glow pulse
      if (canEmergency) {
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.5)';
        ctx.lineWidth = 2 + Math.sin(tick * 0.1) * 2;
        ctx.stroke();
      }
      ctx.restore();

      // 4. Draw Vents
      for (const v of VENTS) {
        ctx.save();
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(v.x - 18, v.y - 12, 36, 24);
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 2;
        ctx.strokeRect(v.x - 18, v.y - 12, 36, 24);

        // Vent grates
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 2;
        for (let gx = -12; gx <= 12; gx += 6) {
          ctx.beginPath();
          ctx.moveTo(v.x + gx, v.y - 8);
          ctx.lineTo(v.x + gx, v.y + 8);
          ctx.stroke();
        }
        ctx.restore();
      }

      // 5. Draw Tasks Terminals
      for (const t of tasks) {
        ctx.save();
        const isCompleted = t.completed;

        // Terminal Base
        ctx.fillStyle = isCompleted ? '#065f46' : '#78350f';
        ctx.fillRect(t.x - 14, t.y - 14, 28, 28);
        ctx.strokeStyle = isCompleted ? '#10b981' : '#f59e0b';
        ctx.lineWidth = 3;
        ctx.strokeRect(t.x - 14, t.y - 14, 28, 28);

        // Screen
        ctx.fillStyle = isCompleted ? '#34d399' : '#fbbf24';
        ctx.fillRect(t.x - 8, t.y - 8, 16, 16);

        // Exclamation mark if uncompleted
        if (!isCompleted) {
          const bounce = Math.sin(tick * 0.12) * 4;
          ctx.font = 'bold 12px "Press Start 2P", monospace';
          ctx.fillStyle = '#f59e0b';
          ctx.textAlign = 'center';
          ctx.fillText('!', t.x, t.y - 20 + bounce);
        }
        ctx.restore();
      }

      // 6. Draw Dead Bodies
      for (const b of deadBodies) {
        drawDeadBody(ctx, b);
      }

      // 7. Draw Characters (Alive & Ghosts)
      // Sort by Y so beans overlap naturally
      const sortedCharacters = [...characters].sort((a, b) => a.y - b.y);
      for (const char of sortedCharacters) {
        if (char.state !== 'dead') {
          drawCharacter(ctx, char, tick);
        }
      }

      // 8. Vision Lighting / Darkness Overlay
      // Impostor sees normally; Crewmate sight reduced if lights sabotaged!
      const isImpostor = player.role === 'impostor';
      const isLightsOut = sabotage.active === 'lights';
      const baseRadius = isLightsOut ? (isImpostor ? 280 : 85) : 340;

      ctx.save();
      // Create radial gradient for flashlight/vision
      const grad = ctx.createRadialGradient(
        player.x,
        player.y,
        baseRadius * 0.6,
        player.x,
        player.y,
        baseRadius
      );
      grad.addColorStop(0, 'rgba(0, 0, 0, 0)');
      grad.addColorStop(1, 'rgba(0, 0, 0, 0.96)');

      // Draw dark overlay covering everything except player circle
      ctx.fillStyle = grad;
      ctx.beginPath();
      // Outer box
      ctx.rect(camX - 50, camY - 50, viewW + 100, viewH + 100);
      ctx.fill();

      // If sabotage alert (Reactor/O2), pulse red ambient flash
      if (sabotage.active === 'reactor' || sabotage.active === 'o2') {
        const redAlpha = (Math.sin(tick * 0.15) + 1) * 0.12;
        ctx.fillStyle = `rgba(239, 68, 68, ${redAlpha})`;
        ctx.fillRect(camX, camY, viewW, viewH);
      }
      ctx.restore();

      // 9. Prompt Highlights
      if (nearbyTask) {
        drawPromptBadge(ctx, nearbyTask.x, nearbyTask.y - 30, '[A] USE TASK', '#34d399');
      } else if (nearbyVent && player.role === 'impostor') {
        drawPromptBadge(ctx, nearbyVent.x, nearbyVent.y - 25, '[B] VENT', '#38bdf8');
      } else if (nearbyBody) {
        drawPromptBadge(ctx, nearbyBody.x, nearbyBody.y - 35, '[X] REPORT BODY', '#ef4444');
      } else if (canAccessComms) {
        drawPromptBadge(ctx, 1330, 1100, '[A] COMMS (GMAIL & FORMS)', '#f59e0b');
      } else if (canEmergency) {
        drawPromptBadge(ctx, EMERGENCY_BUTTON.x, EMERGENCY_BUTTON.y - 45, '[A] EMERGENCY', '#f59e0b');
      }

      ctx.restore();

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [
    player,
    characters,
    deadBodies,
    tasks,
    sabotage,
    nearbyTask,
    nearbyVent,
    nearbyBody,
    canEmergency,
    canAccessComms,
  ]);

  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!onCanvasClick || !canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    const clickX = e.clientX - rect.x;
    const clickY = e.clientY - rect.y;

    // Convert to world coords
    const worldX = clickX - canvasRef.current.width / 2 + player.x;
    const worldY = clickY - canvasRef.current.height / 2 + player.y;
    onCanvasClick(worldX, worldY);
  };

  return (
    <canvas
      ref={canvasRef}
      onClick={handleClick}
      className="w-full h-full block bg-zinc-950 cursor-crosshair select-none"
    />
  );
};

/**
 * Draws a pixelated Bean Character
 */
function drawCharacter(
  ctx: CanvasRenderingContext2D,
  char: Character,
  tick: number
) {
  ctx.save();
  ctx.translate(char.x, char.y);

  const colors = COLOR_MAP[char.color] || COLOR_MAP.red;
  const isGhost = char.state === 'ghost';
  const isMoving = char.state === 'walking';
  const facingLeft = char.facing === 'left';

  if (isGhost) {
    ctx.globalAlpha = 0.5;
  }

  // Flip horizontally if facing left
  if (facingLeft) {
    ctx.scale(-1, 1);
  }

  // Walk bobbing animation
  const bob = isMoving ? Math.sin(tick * 0.3) * 3 : 0;
  const legSwing = isMoving ? Math.sin(tick * 0.3) * 4 : 0;

  // Shadow
  ctx.beginPath();
  ctx.ellipse(0, 16, 14, 5, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
  ctx.fill();

  // Backpack
  ctx.fillStyle = colors.shadow;
  ctx.fillRect(-18, -12 + bob, 7, 20);
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(-18, -12 + bob, 7, 20);

  // Legs
  if (!isGhost) {
    // Left leg
    ctx.fillStyle = colors.body;
    ctx.fillRect(-10, 8 + bob - legSwing, 8, 9);
    ctx.strokeRect(-10, 8 + bob - legSwing, 8, 9);

    // Right leg
    ctx.fillRect(2, 8 + bob + legSwing, 8, 9);
    ctx.strokeRect(2, 8 + bob + legSwing, 8, 9);
  }

  // Main Bean Body
  ctx.beginPath();
  // Pill shape
  ctx.roundRect(-12, -22 + bob, 24, 32, [12, 12, 6, 6]);
  ctx.fillStyle = colors.body;
  ctx.fill();
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 2.5;
  ctx.stroke();

  // Visor
  ctx.beginPath();
  ctx.roundRect(1, -16 + bob, 14, 10, [5, 5, 5, 5]);
  ctx.fillStyle = '#67e8f9';
  ctx.fill();
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Visor reflection shine
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(3, -14 + bob, 5, 3);

  // Hats
  drawHat(ctx, char.hat, bob);

  // Reset flip for text
  if (facingLeft) {
    ctx.scale(-1, 1);
  }

  // Name tag & Ping HUD above character
  ctx.font = '8px "Press Start 2P", monospace';
  ctx.fillStyle = char.isPlayer ? '#38bdf8' : '#ffffff';
  ctx.textAlign = 'center';
  ctx.fillText(char.name, 0, -32 + bob);

  // Subtle ping latency label
  ctx.font = '6px "Press Start 2P", monospace';
  ctx.fillStyle = char.pingMs > 250 ? '#ef4444' : '#10b981';
  ctx.fillText(`${char.pingMs}ms`, 0, -42 + bob);

  ctx.restore();
}

/**
 * Draws Hats
 */
function drawHat(ctx: CanvasRenderingContext2D, hat: HatType, bob: number) {
  if (hat === 'none') return;

  ctx.save();
  if (hat === 'mario') {
    // Red Mario Cap
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.ellipse(0, -23 + bob, 12, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    // Cap visor/brim
    ctx.fillRect(4, -22 + bob, 9, 3);
  } else if (hat === 'crown') {
    // Golden Crown
    ctx.fillStyle = '#fbbf24';
    ctx.beginPath();
    ctx.moveTo(-9, -23 + bob);
    ctx.lineTo(-9, -32 + bob);
    ctx.lineTo(-4, -27 + bob);
    ctx.lineTo(0, -34 + bob);
    ctx.lineTo(4, -27 + bob);
    ctx.lineTo(9, -32 + bob);
    ctx.lineTo(9, -23 + bob);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  } else if (hat === 'sprout') {
    // Green Leaf Sprout
    ctx.strokeStyle = '#15803d';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(0, -22 + bob);
    ctx.lineTo(0, -28 + bob);
    ctx.stroke();
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.ellipse(-4, -30 + bob, 5, 3, -0.4, 0, Math.PI * 2);
    ctx.fill();
    ctx.beginPath();
    ctx.ellipse(4, -30 + bob, 5, 3, 0.4, 0, Math.PI * 2);
    ctx.fill();
  } else if (hat === 'halo') {
    // Angel Halo
    ctx.strokeStyle = '#fef08a';
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(0, -32 + bob, 11, 4, 0, 0, Math.PI * 2);
    ctx.stroke();
  } else if (hat === 'egg') {
    // Fried Egg
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    ctx.ellipse(0, -24 + bob, 10, 4, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = '#f59e0b';
    ctx.beginPath();
    ctx.arc(1, -24 + bob, 3.5, 0, Math.PI * 2);
    ctx.fill();
  } else if (hat === 'detective') {
    // Detective Fedora
    ctx.fillStyle = '#78350f';
    ctx.fillRect(-12, -24 + bob, 24, 4);
    ctx.fillRect(-8, -32 + bob, 16, 9);
    ctx.strokeRect(-8, -32 + bob, 16, 9);
  }
  ctx.restore();
}

/**
 * Draws dead body (bone sticking out of lower half)
 */
function drawDeadBody(ctx: CanvasRenderingContext2D, body: DeadBody) {
  ctx.save();
  ctx.translate(body.x, body.y);

  const colors = COLOR_MAP[body.color] || COLOR_MAP.red;

  // Shadow
  ctx.beginPath();
  ctx.ellipse(0, 10, 16, 6, 0, 0, Math.PI * 2);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
  ctx.fill();

  // Bottom half of body
  ctx.fillStyle = colors.body;
  ctx.fillRect(-12, 0, 24, 12);
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 2.5;
  ctx.strokeRect(-12, 0, 24, 12);

  // Red flesh top
  ctx.fillStyle = '#991b1b';
  ctx.fillRect(-11, -1, 22, 3);

  // Bone sticking out
  ctx.fillStyle = '#f8fafc';
  ctx.fillRect(-2, -12, 4, 12);
  ctx.strokeRect(-2, -12, 4, 12);
  // Bone joint head
  ctx.beginPath();
  ctx.arc(-2, -12, 3, 0, Math.PI * 2);
  ctx.arc(2, -12, 3, 0, Math.PI * 2);
  ctx.fill();
  ctx.stroke();

  ctx.restore();
}

/**
 * Prompt badge overlay
 */
function drawPromptBadge(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  text: string,
  color: string
) {
  ctx.save();
  ctx.font = 'bold 9px "Press Start 2P", monospace';
  const width = ctx.measureText(text).width;

  ctx.fillStyle = '#0f172a';
  ctx.fillRect(x - width / 2 - 6, y - 8, width + 12, 18);
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.strokeRect(x - width / 2 - 6, y - 8, width + 12, 18);

  ctx.fillStyle = color;
  ctx.textAlign = 'center';
  ctx.fillText(text, x, y + 5);
  ctx.restore();
}
