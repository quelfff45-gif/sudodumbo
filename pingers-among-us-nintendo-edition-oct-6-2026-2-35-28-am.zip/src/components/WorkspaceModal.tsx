import React, { useState, useEffect } from 'react';
import { User } from 'firebase/auth';
import {
  initAuth,
  googleSignIn,
  googleSignOut,
  getAccessToken,
} from '../services/auth';
import {
  listGmailMessages,
  getGmailMessage,
  sendGmailMessage,
  GmailMessageSummary,
  GmailFullMessage,
} from '../services/gmailApi';
import {
  listUserForms,
  getFormDetails,
  getFormResponses,
  createAmongUsInvestigationForm,
  GoogleFormSummary,
  GoogleFormDetails,
  FormResponseSummary,
} from '../services/formsApi';
import { sound } from '../audio/soundEngine';
import {
  X,
  Mail,
  FileText,
  Send,
  PlusCircle,
  ExternalLink,
  RefreshCw,
  LogOut,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Clock,
  User as UserIcon,
  ChevronRight,
} from 'lucide-react';

interface WorkspaceModalProps {
  onClose: () => void;
}

export const WorkspaceModal: React.FC<WorkspaceModalProps> = ({ onClose }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [activeTab, setActiveTab] = useState<'gmail' | 'forms'>('gmail');

  // Gmail states
  const [messages, setMessages] = useState<GmailMessageSummary[]>([]);
  const [selectedMessage, setSelectedMessage] = useState<GmailFullMessage | null>(null);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [loadingDetail, setLoadingDetail] = useState(false);
  const [composeOpen, setComposeOpen] = useState(false);
  const [composeTo, setComposeTo] = useState('');
  const [composeSubject, setComposeSubject] = useState('URGENT: Crewmate Transmission - USS Pinger');
  const [composeBody, setComposeBody] = useState(
    'Attention Crewmates:\n\nRecent sonar radar calibrations indicate high latency anomalies in Electrical. Stay in pairs and report any suspicious vent movement immediately!\n\n-- Roman James Productions · Space Defense Network'
  );
  const [isSending, setIsSending] = useState(false);

  // Forms states
  const [formsList, setFormsList] = useState<GoogleFormSummary[]>([]);
  const [selectedForm, setSelectedForm] = useState<GoogleFormDetails | null>(null);
  const [selectedFormResponses, setSelectedFormResponses] = useState<FormResponseSummary[]>([]);
  const [loadingForms, setLoadingForms] = useState(false);
  const [loadingFormDetail, setLoadingFormDetail] = useState(false);
  const [isCreatingForm, setIsCreatingForm] = useState(false);
  const [newFormUrl, setNewFormUrl] = useState<string | null>(null);

  // Confirmation modal state (for destructive/mutating operations)
  const [confirmation, setConfirmation] = useState<{
    title: string;
    description: string;
    onConfirm: () => void;
  } | null>(null);

  const [feedback, setFeedback] = useState<string | null>(null);

  // Initialize Auth
  useEffect(() => {
    sound.trigger('modal_open');
    const unsubscribe = initAuth(
      (currentUser, accessToken) => {
        setUser(currentUser);
        setToken(accessToken);
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  // Fetch data when authenticated
  useEffect(() => {
    if (user && token) {
      if (activeTab === 'gmail') {
        fetchMessages();
      } else {
        fetchForms();
      }
    }
  }, [user, token, activeTab]);

  const handleSignIn = async () => {
    setIsLoggingIn(true);
    setFeedback(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setToken(res.accessToken);
        sound.playTaskComplete();
      }
    } catch (err: any) {
      console.error('Sign-in failed:', err);
      setFeedback(`Sign-in error: ${err.message || 'Authorization failed'}`);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleSignOut = async () => {
    sound.playUiClick();
    await googleSignOut();
    setUser(null);
    setToken(null);
    setMessages([]);
    setFormsList([]);
    setSelectedMessage(null);
    setSelectedForm(null);
  };

  const fetchMessages = async () => {
    setLoadingMessages(true);
    setFeedback(null);
    try {
      const list = await listGmailMessages(10);
      setMessages(list);
    } catch (err: any) {
      console.error('Failed to load Gmail messages:', err);
      setFeedback(`Gmail: ${err.message}`);
    } finally {
      setLoadingMessages(false);
    }
  };

  const handleSelectMessage = async (msg: GmailMessageSummary) => {
    sound.playUiClick();
    setLoadingDetail(true);
    try {
      const full = await getGmailMessage(msg.id);
      setSelectedMessage(full);
    } catch (err: any) {
      setFeedback(`Failed to load email: ${err.message}`);
    } finally {
      setLoadingDetail(false);
    }
  };

  const handleSendEmailPrompt = () => {
    if (!composeTo.trim()) {
      setFeedback('Please specify a recipient email address.');
      return;
    }
    // Mandatory Confirmation Dialog for mutating user data
    setConfirmation({
      title: 'Confirm Sending Email via Gmail',
      description: `Are you sure you want to send this email to "${composeTo}" with subject "${composeSubject}" from your authorized Gmail account?`,
      onConfirm: async () => {
        setConfirmation(null);
        setIsSending(true);
        try {
          await sendGmailMessage(composeTo, composeSubject, composeBody);
          sound.playTaskComplete();
          setFeedback('Email transmission sent successfully via Gmail!');
          setComposeOpen(false);
          fetchMessages();
        } catch (err: any) {
          setFeedback(`Send error: ${err.message}`);
        } finally {
          setIsSending(false);
        }
      },
    });
  };

  const fetchForms = async () => {
    setLoadingForms(true);
    setFeedback(null);
    try {
      const list = await listUserForms();
      setFormsList(list);
    } catch (err: any) {
      console.error('Failed to load Google Forms:', err);
      setFeedback(`Google Forms: ${err.message}`);
    } finally {
      setLoadingForms(false);
    }
  };

  const handleSelectForm = async (f: GoogleFormSummary) => {
    sound.playUiClick();
    setLoadingFormDetail(true);
    try {
      const [details, responses] = await Promise.all([
        getFormDetails(f.id),
        getFormResponses(f.id),
      ]);
      setSelectedForm(details);
      setSelectedFormResponses(responses);
    } catch (err: any) {
      setFeedback(`Failed to load form details: ${err.message}`);
    } finally {
      setLoadingFormDetail(false);
    }
  };

  const handleCreateInvestigationFormPrompt = () => {
    setConfirmation({
      title: 'Create Google Form for Crew Investigation',
      description:
        'This will create a new "Among Us Crewmate Incident Report" form directly in your Google Forms and Google Drive with preconfigured investigation poll questions. Continue?',
      onConfirm: async () => {
        setConfirmation(null);
        setIsCreatingForm(true);
        try {
          const res = await createAmongUsInvestigationForm(
            'Among Us: Crewmate Investigation & Suspect Poll',
            'Official emergency report form for logging alibis, suspect accusations, and ping latency anomalies aboard the spaceship.'
          );
          sound.playTaskComplete();
          setNewFormUrl(res.responderUri);
          setFeedback('Form created successfully in Google Forms!');
          fetchForms();
        } catch (err: any) {
          setFeedback(`Create Form error: ${err.message}`);
        } finally {
          setIsCreatingForm(false);
        }
      },
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-6 select-none font-pixel text-zinc-100">
      <div className="relative w-full max-w-4xl bg-zinc-950 border-4 border-amber-600 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top Header Bar */}
        <div className="bg-zinc-900 px-4 py-3 border-b-2 border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Radio className="text-amber-400 animate-pulse" size={20} />
            <div>
              <h2 className="font-arcade text-xs sm:text-sm text-amber-400 tracking-wider">
                ROMAN JAMES PRODUCTIONS · COMMS RELAY
              </h2>
              <div className="text-[10px] text-zinc-400 mt-0.5">
                GMAIL TRANSMISSIONS &amp; GOOGLE FORMS SATELLITE LINK
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {user && (
              <button
                onClick={handleSignOut}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[10px] font-arcade rounded border border-zinc-700 cursor-pointer"
              >
                <LogOut size={12} />
                <span>SIGN OUT</span>
              </button>
            )}
            <button
              onClick={() => {
                sound.trigger('modal_close');
                onClose();
              }}
              className="text-zinc-400 hover:text-white p-1 hover:bg-zinc-800 rounded transition-colors cursor-pointer"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Feedback Alert Banner */}
        {feedback && (
          <div className="bg-amber-950/80 border-b border-amber-700 px-4 py-2 text-xs text-amber-300 flex items-center justify-between">
            <span>{feedback}</span>
            <button onClick={() => setFeedback(null)} className="text-amber-400 underline text-[10px]">
              Dismiss
            </button>
          </div>
        )}

        {/* Unauthenticated View */}
        {!user ? (
          <div className="p-8 flex flex-col items-center justify-center text-center my-auto space-y-6">
            <div className="w-16 h-16 rounded-full bg-amber-950/60 border-2 border-amber-500 flex items-center justify-center text-amber-400">
              <Radio size={32} />
            </div>

            <div className="max-w-md">
              <h3 className="font-arcade text-sm text-zinc-100 mb-2">
                SECURE SATELLITE COMMUNICATIONS
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed font-pixel">
                Connect your Google account to read real mission transmissions from <strong>Gmail</strong>, compose space emergency dispatches, and deploy crew investigation polls to <strong>Google Forms</strong>.
              </p>
            </div>

            {/* Official Google Sign-In Button */}
            <button
              onClick={handleSignIn}
              disabled={isLoggingIn}
              className="flex items-center gap-3 px-5 py-3 bg-white hover:bg-zinc-100 text-zinc-800 font-medium text-xs rounded-lg shadow-lg border border-zinc-300 transition-all cursor-pointer active:scale-95 disabled:opacity-60"
            >
              <svg className="w-4 h-4" viewBox="0 0 48 48">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
              </svg>
              <span className="font-sans font-medium text-zinc-800 text-sm">
                {isLoggingIn ? 'Connecting to Google...' : 'Sign in with Google'}
              </span>
            </button>
          </div>
        ) : (
          /* Authenticated Dashboard */
          <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
            {/* User Bar & Subsystem Tabs */}
            <div className="bg-zinc-900/80 px-4 py-2 border-b border-zinc-800 flex flex-wrap items-center justify-between gap-3">
              {/* Profile Chip */}
              <div className="flex items-center gap-2 text-xs">
                {user.photoURL ? (
                  <img src={user.photoURL} alt="" className="w-5 h-5 rounded-full" />
                ) : (
                  <UserIcon size={16} className="text-amber-400" />
                )}
                <span className="font-arcade text-[10px] text-zinc-300">
                  {user.email || user.displayName}
                </span>
              </div>

              {/* Segmented Controls: Gmail vs Google Forms */}
              <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-lg border border-zinc-800 font-arcade text-[10px]">
                <button
                  onClick={() => {
                    sound.playUiClick();
                    setActiveTab('gmail');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all cursor-pointer ${
                    activeTab === 'gmail'
                      ? 'bg-red-900/60 border border-red-500 text-white'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <Mail size={12} />
                  <span>GMAIL DISPATCH</span>
                </button>

                <button
                  onClick={() => {
                    sound.playUiClick();
                    setActiveTab('forms');
                  }}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded transition-all cursor-pointer ${
                    activeTab === 'forms'
                      ? 'bg-purple-900/60 border border-purple-500 text-white'
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  <FileText size={12} />
                  <span>GOOGLE FORMS</span>
                </button>
              </div>
            </div>

            {/* TAB 1: GMAIL VIEW */}
            {activeTab === 'gmail' && (
              <div className="flex-1 flex flex-col md:flex-row overflow-hidden min-h-0">
                {/* Left: Messages List */}
                <div className="w-full md:w-5/12 border-b md:border-b-0 md:border-r border-zinc-800 flex flex-col min-h-0 bg-zinc-950">
                  <div className="p-3 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/40">
                    <span className="font-arcade text-[10px] text-zinc-400">
                      INCOMING TRANSMISSIONS ({messages.length})
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={fetchMessages}
                        disabled={loadingMessages}
                        className="p-1 text-zinc-400 hover:text-white rounded hover:bg-zinc-800 cursor-pointer"
                        title="Refresh"
                      >
                        <RefreshCw size={13} className={loadingMessages ? 'animate-spin' : ''} />
                      </button>
                      <button
                        onClick={() => setComposeOpen(true)}
                        className="flex items-center gap-1 px-2 py-1 bg-red-700 hover:bg-red-600 text-white text-[9px] font-arcade rounded cursor-pointer"
                      >
                        <Send size={10} />
                        <span>COMPOSE</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto divide-y divide-zinc-900">
                    {loadingMessages ? (
                      <div className="p-6 text-center text-xs text-zinc-500 font-arcade animate-pulse">
                        SEARCHING RADIO FREQUENCIES...
                      </div>
                    ) : messages.length === 0 ? (
                      <div className="p-6 text-center text-xs text-zinc-500">
                        No transmissions found in inbox.
                      </div>
                    ) : (
                      messages.map((m) => (
                        <div
                          key={m.id}
                          onClick={() => handleSelectMessage(m)}
                          className={`p-3 text-left hover:bg-zinc-900/80 transition-colors cursor-pointer ${
                            selectedMessage?.id === m.id ? 'bg-red-950/40 border-l-4 border-red-500' : ''
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1 mb-1">
                            <span className="text-[10px] font-arcade text-amber-400 truncate max-w-[160px]">
                              {m.from?.split('<')[0] || 'Unknown Origin'}
                            </span>
                            {m.unread && (
                              <span className="w-2 h-2 rounded-full bg-red-500 shrink-0" />
                            )}
                          </div>
                          <div className="text-xs text-zinc-200 font-pixel font-bold truncate">
                            {m.subject}
                          </div>
                          <div className="text-[10px] text-zinc-500 truncate mt-0.5">
                            {m.snippet}
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Right: Selected Message Detail or Compose Box */}
                <div className="flex-1 flex flex-col min-h-0 bg-zinc-900/30 overflow-y-auto p-4">
                  {composeOpen ? (
                    /* Compose View */
                    <div className="flex flex-col gap-3 h-full">
                      <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                        <span className="font-arcade text-xs text-red-400">
                          TRANSMIT EMERGENCY EMAIL
                        </span>
                        <button
                          onClick={() => setComposeOpen(false)}
                          className="text-xs text-zinc-500 hover:text-white"
                        >
                          Cancel
                        </button>
                      </div>

                      <div>
                        <label className="text-[10px] font-arcade text-zinc-400 block mb-1">
                          RECIPIENT (TO)
                        </label>
                        <input
                          type="email"
                          placeholder="crewmate@example.com"
                          value={composeTo}
                          onChange={(e) => setComposeTo(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-700 rounded p-2 text-xs text-zinc-100 focus:outline-none focus:border-red-500 font-mono"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-arcade text-zinc-400 block mb-1">
                          SUBJECT
                        </label>
                        <input
                          type="text"
                          value={composeSubject}
                          onChange={(e) => setComposeSubject(e.target.value)}
                          className="w-full bg-zinc-950 border border-zinc-700 rounded p-2 text-xs text-zinc-100 focus:outline-none focus:border-red-500 font-mono"
                        />
                      </div>

                      <div className="flex-1 flex flex-col">
                        <label className="text-[10px] font-arcade text-zinc-400 block mb-1">
                          DISPATCH BODY
                        </label>
                        <textarea
                          rows={6}
                          value={composeBody}
                          onChange={(e) => setComposeBody(e.target.value)}
                          className="w-full flex-1 bg-zinc-950 border border-zinc-700 rounded p-2 text-xs text-zinc-100 focus:outline-none focus:border-red-500 font-mono"
                        />
                      </div>

                      <div className="pt-2 flex justify-end">
                        <button
                          onClick={handleSendEmailPrompt}
                          disabled={isSending}
                          className="flex items-center gap-2 px-5 py-2.5 bg-red-600 hover:bg-red-500 text-white font-arcade text-xs rounded border-b-4 border-red-900 cursor-pointer"
                        >
                          <Send size={14} />
                          <span>{isSending ? 'TRANSMITTING...' : 'SEND EMAIL VIA GMAIL'}</span>
                        </button>
                      </div>
                    </div>
                  ) : selectedMessage ? (
                    /* Message Detail View */
                    <div className="flex flex-col gap-3">
                      <div className="pb-3 border-b border-zinc-800">
                        <h3 className="font-arcade text-sm text-zinc-100 mb-1">
                          {selectedMessage.subject}
                        </h3>
                        <div className="text-xs text-zinc-400">
                          FROM: <span className="text-amber-400">{selectedMessage.from}</span>
                        </div>
                        {selectedMessage.date && (
                          <div className="text-[10px] text-zinc-500 mt-1">
                            {selectedMessage.date}
                          </div>
                        )}
                      </div>

                      <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800 text-xs text-zinc-300 whitespace-pre-wrap font-mono leading-relaxed max-h-[360px] overflow-y-auto">
                        {selectedMessage.bodyText || selectedMessage.snippet}
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-center text-zinc-600 font-arcade text-xs">
                      SELECT A TRANSMISSION TO DECODE
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* TAB 2: GOOGLE FORMS VIEW */}
            {activeTab === 'forms' && (
              <div className="flex-1 flex flex-col md:flex-row overflow-hidden min-h-0">
                {/* Left: User's Forms List */}
                <div className="w-full md:w-5/12 border-b md:border-b-0 md:border-r border-zinc-800 flex flex-col min-h-0 bg-zinc-950">
                  <div className="p-3 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/40">
                    <span className="font-arcade text-[10px] text-zinc-400">
                      GOOGLE FORMS ({formsList.length})
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={fetchForms}
                        disabled={loadingForms}
                        className="p-1 text-zinc-400 hover:text-white rounded hover:bg-zinc-800 cursor-pointer"
                        title="Refresh"
                      >
                        <RefreshCw size={13} className={loadingForms ? 'animate-spin' : ''} />
                      </button>
                      <button
                        onClick={handleCreateInvestigationFormPrompt}
                        disabled={isCreatingForm}
                        className="flex items-center gap-1 px-2.5 py-1 bg-purple-700 hover:bg-purple-600 text-white text-[9px] font-arcade rounded cursor-pointer"
                      >
                        <PlusCircle size={10} />
                        <span>CREATE POLL</span>
                      </button>
                    </div>
                  </div>

                  <div className="flex-1 overflow-y-auto divide-y divide-zinc-900">
                    {loadingForms ? (
                      <div className="p-6 text-center text-xs text-zinc-500 font-arcade animate-pulse">
                        ACCESSING DRIVE FORMS...
                      </div>
                    ) : formsList.length === 0 ? (
                      <div className="p-6 text-center text-xs text-zinc-500">
                        No Google Forms found in your Google Drive. Click "CREATE POLL" above to create an incident survey!
                      </div>
                    ) : (
                      formsList.map((f) => (
                        <div
                          key={f.id}
                          onClick={() => handleSelectForm(f)}
                          className={`p-3 text-left hover:bg-zinc-900/80 transition-colors cursor-pointer ${
                            selectedForm?.formId === f.id ? 'bg-purple-950/40 border-l-4 border-purple-500' : ''
                          }`}
                        >
                          <div className="text-xs text-zinc-200 font-pixel font-bold truncate">
                            {f.title}
                          </div>
                          {f.modifiedTime && (
                            <div className="text-[10px] text-zinc-500 mt-1">
                              Updated: {new Date(f.modifiedTime).toLocaleDateString()}
                            </div>
                          )}
                        </div>
                      ))
                    )}
                  </div>
                </div>

                {/* Right: Selected Form Details & Responses */}
                <div className="flex-1 flex flex-col min-h-0 bg-zinc-900/30 overflow-y-auto p-4">
                  {newFormUrl && (
                    <div className="mb-4 p-3 bg-purple-950/60 border border-purple-500 rounded-lg flex items-center justify-between text-xs text-purple-200">
                      <div>
                        <div className="font-arcade text-[10px] text-purple-300">
                          NEW FORM READY FOR CREWMATE VOTING!
                        </div>
                        <div className="text-[10px] text-zinc-400 mt-0.5">
                          Share this link with crewmates or view in browser.
                        </div>
                      </div>
                      <a
                        href={newFormUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="flex items-center gap-1 px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded text-xs font-arcade"
                      >
                        <span>OPEN</span>
                        <ExternalLink size={12} />
                      </a>
                    </div>
                  )}

                  {loadingFormDetail ? (
                    <div className="flex-1 flex items-center justify-center text-xs text-zinc-500 font-arcade animate-pulse">
                      LOADING FORM SCHEMATIC...
                    </div>
                  ) : selectedForm ? (
                    <div className="space-y-4">
                      {/* Form Header */}
                      <div className="pb-3 border-b border-zinc-800 flex items-start justify-between gap-4">
                        <div>
                          <h3 className="font-arcade text-sm text-purple-300">
                            {selectedForm.info.title}
                          </h3>
                          {selectedForm.info.description && (
                            <p className="text-xs text-zinc-400 mt-1">
                              {selectedForm.info.description}
                            </p>
                          )}
                          <div className="text-[10px] text-zinc-500 mt-1 font-arcade">
                            RESPONSES RECORDED: {selectedFormResponses.length}
                          </div>
                        </div>

                        {selectedForm.responderUri && (
                          <a
                            href={selectedForm.responderUri}
                            target="_blank"
                            rel="noreferrer"
                            className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-700 hover:bg-purple-600 text-white text-[10px] font-arcade rounded border border-purple-500 shrink-0"
                          >
                            <span>VIEW IN FORMS</span>
                            <ExternalLink size={12} />
                          </a>
                        )}
                      </div>

                      {/* Questions List */}
                      <div>
                        <div className="font-arcade text-[10px] text-zinc-400 mb-2">
                          FORM ITEMS &amp; QUESTIONS:
                        </div>
                        <div className="space-y-2">
                          {(selectedForm.items || []).map((item, idx) => (
                            <div
                              key={item.itemId || idx}
                              className="p-3 bg-zinc-950 rounded-lg border border-zinc-800"
                            >
                              <div className="text-xs text-zinc-200 font-bold mb-1">
                                {idx + 1}. {item.title || '(Untitled Question)'}
                              </div>
                              {item.questionItem?.question.choiceQuestion?.options && (
                                <div className="space-y-1 mt-2 text-[10px] text-zinc-400 pl-2">
                                  {item.questionItem.question.choiceQuestion.options.map((opt, oIdx) => (
                                    <div key={oIdx} className="flex items-center gap-1.5">
                                      <span className="w-2 h-2 rounded-full border border-zinc-600" />
                                      <span>{opt.value}</span>
                                    </div>
                                  ))}
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center text-center text-zinc-600 font-arcade text-xs">
                      SELECT A FORM TO INSPECT OR CLICK "CREATE POLL"
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Confirmation Dialog (Mandatory for destructive/mutating actions) */}
      {confirmation && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/90 p-4 font-arcade text-zinc-100">
          <div className="max-w-md w-full bg-zinc-900 border-4 border-amber-500 rounded-xl p-6 shadow-2xl">
            <div className="flex items-center gap-2 text-amber-400 mb-3">
              <AlertTriangle size={20} />
              <h3 className="text-xs font-arcade">{confirmation.title}</h3>
            </div>
            <p className="font-pixel text-xs text-zinc-300 leading-relaxed mb-6">
              {confirmation.description}
            </p>
            <div className="flex gap-3 justify-end font-arcade text-[10px]">
              <button
                onClick={() => setConfirmation(null)}
                className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded cursor-pointer"
              >
                CANCEL
              </button>
              <button
                onClick={confirmation.onConfirm}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-bold rounded border-b-2 border-amber-800 cursor-pointer"
              >
                CONFIRM &amp; PROCEED
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
