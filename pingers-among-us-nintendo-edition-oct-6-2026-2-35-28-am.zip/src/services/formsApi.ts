import { getAccessToken } from './auth';

export interface GoogleFormSummary {
  id: string;
  title: string;
  webViewLink?: string;
  responderUri?: string;
  modifiedTime?: string;
}

export interface GoogleFormDetails {
  formId: string;
  info: {
    title: string;
    description?: string;
    documentTitle?: string;
  };
  responderUri?: string;
  items?: Array<{
    itemId: string;
    title?: string;
    description?: string;
    questionItem?: {
      question: {
        questionId: string;
        choiceQuestion?: {
          type: string;
          options: Array<{ value: string }>;
        };
        textQuestion?: {
          paragraph?: boolean;
        };
      };
    };
  }>;
}

export interface FormResponseSummary {
  responseId: string;
  createTime: string;
  lastSubmittedTime: string;
  answers?: Record<
    string,
    {
      questionId: string;
      textAnswers?: {
        answers?: Array<{ value: string }>;
      };
    }
  >;
}

export async function listUserForms(): Promise<GoogleFormSummary[]> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated.');

  // List Google Forms from Drive API
  const q = "mimeType = 'application/vnd.google-apps.form' and trashed = false";
  const fields = 'files(id, name, webViewLink, modifiedTime)';
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=${encodeURIComponent(
      fields
    )}&pageSize=20`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to fetch forms (${res.status})`);
  }

  const data = await res.json();
  return (data.files || []).map((file: any) => ({
    id: file.id,
    title: file.name || 'Untitled Form',
    webViewLink: file.webViewLink,
    modifiedTime: file.modifiedTime,
  }));
}

export async function getFormDetails(formId: string): Promise<GoogleFormDetails> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated.');

  const res = await fetch(`https://forms.googleapis.com/v1/forms/${formId}`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to fetch form details (${res.status})`);
  }

  return res.json();
}

export async function getFormResponses(formId: string): Promise<FormResponseSummary[]> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated.');

  const res = await fetch(`https://forms.googleapis.com/v1/forms/${formId}/responses`, {
    headers: { Authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    // Some forms don't have responses yet or return 404
    return [];
  }

  const data = await res.json();
  return data.responses || [];
}

export async function createAmongUsInvestigationForm(
  title: string,
  description: string
): Promise<{ formId: string; responderUri: string }> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated.');

  // 1. Create the blank form
  const createRes = await fetch('https://forms.googleapis.com/v1/forms', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      info: {
        title,
        documentTitle: title,
      },
    }),
  });

  if (!createRes.ok) {
    const errorData = await createRes.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to create form (${createRes.status})`);
  }

  const newForm = await createRes.json();
  const formId = newForm.formId;

  // 2. Add Among Us investigation questions via batchUpdate
  const batchRequests = {
    includeFormInResponse: true,
    requests: [
      {
        createItem: {
          item: {
            title: 'Who is the most suspicious crewmate aboard?',
            description: 'Select the primary suspect based on recent room sightings and vent activity.',
            questionItem: {
              question: {
                required: true,
                choiceQuestion: {
                  type: 'RADIO',
                  options: [
                    { value: 'Red (Suspect)' },
                    { value: 'Blue' },
                    { value: 'Green' },
                    { value: 'Cyan' },
                    { value: 'Pink' },
                    { value: 'Yellow' },
                    { value: 'Other' },
                  ],
                },
              },
            },
          },
          location: { index: 0 },
        },
      },
      {
        createItem: {
          item: {
            title: 'Where were you during the last sabotage or dead body discovery?',
            description: 'State your alibi room.',
            questionItem: {
              question: {
                required: true,
                choiceQuestion: {
                  type: 'CHECKBOX',
                  options: [
                    { value: 'Cafeteria' },
                    { value: 'Navigation (Calibrating Sonar Pinger)' },
                    { value: 'Electrical (Fixing Wiring)' },
                    { value: 'Admin (Swiping Card)' },
                    { value: 'MedBay (Scanning)' },
                    { value: 'Weapons (Shooting Asteroids)' },
                    { value: 'Reactor' },
                    { value: 'Security (Watching CCTV)' },
                  ],
                },
              },
            },
          },
          location: { index: 1 },
        },
      },
      {
        createItem: {
          item: {
            title: 'Additional notes or ping latency anomalies:',
            questionItem: {
              question: {
                required: false,
                textQuestion: {
                  paragraph: true,
                },
              },
            },
          },
          location: { index: 2 },
        },
      },
    ],
  };

  const updateRes = await fetch(`https://forms.googleapis.com/v1/forms/${formId}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(batchRequests),
  });

  if (!updateRes.ok) {
    console.warn('Batch update of questions had non-critical issue:', await updateRes.text());
  }

  return {
    formId,
    responderUri: newForm.responderUri || `https://docs.google.com/forms/d/${formId}/viewform`,
  };
}
