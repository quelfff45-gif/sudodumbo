import React, { useState, useEffect } from 'react';
import { Character, BeanColor } from '../types';
import { SECURITY_CAMERAS } from '../game/mapData';
import { sound } from '../audio/soundEngine';
import { X, Video, ShieldAlert } from 'lucide-react';

interface SecurityCamerasModalProps {
  characters: Character[];
  onClose: () => void;
}

const COLOR_MAP: Record<BeanColor, string> = {
  red: '#ef4444',
  blue: '#3b82f6',
  green: '#22c55e',
  pink: '#ec4899',
  orange: '#f97316',
  yellow: '#eab308',
  black: '#475569',
  white: '#f8fafc',
  purple: '#a855f7',
  cyan: '#06b6d4',
};

export const SecurityCamerasModal: React.FC<SecurityCamerasModalProps> = ({
  characters,
  onClose,
}) => {
  const [activeCamIndex, setActiveCamIndex] = useState(0);
  const activeCam = SECURITY_CAMERAS[activeCamIndex];

  useEffect(() => {
    sound.trigger('modal_open');
  }, []);

  const handleClose = () => {
    sound.trigger('modal_close');
    onClose();
  };

  // Beans in the active camera's room
  const visibleBeans = characters.filter(
    (c) => c.currentRoom === activeCam.room && c.state !== 'dead' && c.state !== 'ghost'
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="relative w-full max-w-4xl bg-zinc-950 border-4 border-zinc-700 rounded-2xl overflow-hidden font-pixel text-zinc-100 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between bg-zinc-900 px-4 py-3 border-b-2 border-zinc-700">
          <div className="flex items-center gap-2">
            <Video className="text-red-500 animate-pulse" size={20} />
            <span className="font-arcade text-xs text-red-500 tracking-wider">
              SECURITY SURVEILLANCE FEED - CCTV ONLINE
            </span>
          </div>
          <button
            onClick={handleClose}
            className="text-zinc-400 hover:text-white p-1 hover:bg-zinc-800 rounded transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Main Feed Viewport */}
        <div className="p-4 bg-zinc-950 flex flex-col md:flex-row gap-4">
          <div className="relative flex-1 h-80 bg-zinc-900 border-2 border-zinc-700 rounded-xl overflow-hidden flex items-center justify-center crt-scanlines">
            {/* Camera Info Overlay */}
            <div className="absolute top-3 left-3 z-10 flex items-center gap-2 font-arcade text-[10px] text-red-400">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              <span>REC</span>
              <span>{activeCam.name}</span>
            </div>

            <div className="absolute top-3 right-3 z-10 font-lcd text-lg text-emerald-400">
              {new Date().toISOString().slice(11, 19)}
            </div>

            {/* Room background wireframe */}
            <div className="w-full h-full relative p-8 flex items-center justify-around bg-gradient-to-b from-zinc-950/70 to-zinc-900/90">
              {visibleBeans.length === 0 ? (
                <div className="text-zinc-600 font-arcade text-xs tracking-widest animate-pulse">
                  [ NO ACTIVITY IN SECTOR ]
                </div>
              ) : (
                visibleBeans.map((bean) => (
                  <div
                    key={bean.id}
                    className="flex flex-col items-center animate-bounce"
                  >
                    <div
                      className="w-10 h-14 rounded-t-full rounded-b-md border-2 border-black relative"
                      style={{ backgroundColor: COLOR_MAP[bean.color] }}
                    >
                      <div className="absolute top-3 left-1 w-6 h-3 bg-cyan-200 border border-black rounded-full" />
                    </div>
                    <span className="font-arcade text-[9px] text-zinc-300 mt-1">
                      {bean.name}
                    </span>
                  </div>
                ))
              )}
            </div>

            {/* Subtle camera static noise effect */}
            <div className="absolute inset-0 bg-emerald-500/5 pointer-events-none" />
          </div>

          {/* Camera switcher tabs */}
          <div className="flex md:flex-col gap-2 w-full md:w-56">
            {SECURITY_CAMERAS.map((cam, idx) => (
              <button
                key={cam.id}
                onClick={() => setActiveCamIndex(idx)}
                className={`flex-1 p-3 text-left font-arcade text-[10px] rounded-lg border-2 transition-all cursor-pointer ${
                  activeCamIndex === idx
                    ? 'bg-red-950/80 border-red-500 text-white'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:border-zinc-600'
                }`}
              >
                <div>CAM 0{idx + 1}</div>
                <div className="text-[9px] text-zinc-500 truncate mt-1">
                  {cam.name.replace(/^CAM \d+: /, '')}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
