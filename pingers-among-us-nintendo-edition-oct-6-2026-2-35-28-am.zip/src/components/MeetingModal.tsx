import React, { useState, useEffect } from 'react';
import { Character, MeetingState, BeanColor } from '../types';
import { sound } from '../audio/soundEngine';
import { AlertTriangle, UserX, MessageSquare, Check, ThumbsUp } from 'lucide-react';

interface MeetingModalProps {
  characters: Character[];
  meeting: MeetingState;
  onCastVote: (voterId: string, targetId: string) => void;
  onCloseMeeting: () => void;
}

const COLOR_MAP: Record<BeanColor, string> = {
  red: '#ef4444',
  blue: '#3b82f6',
  green: '#22c55e',
  pink: '#ec4899',
  orange: '#f97316',
  yellow: '#eab308',
  black: '#475569',
  white: '#f8fafc',
  purple: '#a855f7',
  cyan: '#06b6d4',
};

export const MeetingModal: React.FC<MeetingModalProps> = ({
  characters,
  meeting,
  onCastVote,
  onCloseMeeting,
}) => {
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null);
  const [hasConfirmedVote, setHasConfirmedVote] = useState(meeting.hasVoted);
  const [votesRevealed, setVotesRevealed] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(15);
  const [ejectionSequenceActive, setEjectionSequenceActive] = useState(false);
  const [ejectedChar, setEjectedChar] = useState<Character | null>(null);

  const player = characters.find((c) => c.isPlayer);

  // Play siren on mount
  useEffect(() => {
    sound.playEmergencyAlarm();
  }, []);

  // Meeting timer
  useEffect(() => {
    if (votesRevealed || ejectionSequenceActive) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          // Auto skip if player hasn't voted
          if (!hasConfirmedVote && player) {
            handleVote('skip');
          }
          handleRevealVotes();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [hasConfirmedVote, votesRevealed, ejectionSequenceActive]);

  const handleVote = (targetId: string) => {
    if (hasConfirmedVote || !player || player.state === 'dead' || player.state === 'ghost') return;
    sound.trigger('vote_cast');
    setSelectedTarget(targetId);
    setHasConfirmedVote(true);
    onCastVote(player.id, targetId);
  };

  const handleRevealVotes = () => {
    setVotesRevealed(true);
    sound.playCardBeep(true);

    // Calculate majority
    const voteCounts: Record<string, number> = {};
    Object.values(meeting.votes).forEach((target) => {
      voteCounts[target] = (voteCounts[target] || 0) + 1;
    });

    let topTarget = 'skip';
    let maxVotes = 0;
    let tie = false;

    Object.entries(voteCounts).forEach(([target, count]) => {
      if (count > maxVotes) {
        maxVotes = count;
        topTarget = target;
        tie = false;
      } else if (count === maxVotes) {
        tie = true;
      }
    });

    setTimeout(() => {
      setEjectionSequenceActive(true);
      sound.playEjection();

      if (!tie && topTarget !== 'skip') {
        const victim = characters.find((c) => c.id === topTarget);
        setEjectedChar(victim || null);
      } else {
        setEjectedChar(null);
      }
    }, 3200);
  };

  // If in ejection cutscene
  if (ejectionSequenceActive) {
    const isImpostor = ejectedChar?.role === 'impostor';
    const remainingImpostors = characters.filter(
      (c) => c.role === 'impostor' && c.id !== ejectedChar?.id && c.state !== 'dead' && c.state !== 'ghost'
    ).length;

    return (
      <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black font-arcade text-zinc-100 p-6 overflow-hidden">
        {/* Starfield */}
        <div className="absolute inset-0 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:24px_24px] opacity-40 animate-pulse" />

        {/* Ejected Bean Floating */}
        {ejectedChar && (
          <div className="relative mb-12 animate-bounce">
            <div
              className="w-20 h-28 rounded-t-full rounded-b-xl border-4 border-black shadow-2xl relative rotate-45 transition-transform"
              style={{ backgroundColor: COLOR_MAP[ejectedChar.color] }}
            >
              {/* Visor */}
              <div className="absolute top-6 left-2 w-12 h-7 bg-cyan-200 border-2 border-black rounded-full" />
              {/* Backpack */}
              <div
                className="absolute top-6 -left-4 w-5 h-14 rounded border-2 border-black"
                style={{ backgroundColor: COLOR_MAP[ejectedChar.color] }}
              />
            </div>
          </div>
        )}

        {/* Nintendo dialog text */}
        <div className="z-10 text-center max-w-xl bg-zinc-900/90 border-4 border-zinc-700 p-6 rounded-xl shadow-2xl">
          {ejectedChar ? (
            <>
              <p className="text-lg md:text-xl text-amber-400 mb-3 uppercase tracking-wider">
                {ejectedChar.name} was ejected.
              </p>
              <p className="text-sm md:text-base text-zinc-300">
                {ejectedChar.name} {isImpostor ? 'was An Impostor.' : 'was not An Impostor.'}
              </p>
              <p className="text-xs text-zinc-500 mt-2">
                {remainingImpostors} Impostor{remainingImpostors === 1 ? '' : 's'} remain.
              </p>
            </>
          ) : (
            <>
              <p className="text-lg text-amber-400 mb-2">NO ONE WAS EJECTED.</p>
              <p className="text-sm text-zinc-400">(Skipped or Tied Vote)</p>
            </>
          )}

          <button
            onClick={onCloseMeeting}
            className="mt-6 px-6 py-3 bg-red-600 hover:bg-red-500 text-white text-xs font-arcade rounded border-b-4 border-red-900 cursor-pointer uppercase transition-colors"
          >
            [A] PROCEED TO SHIP
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
      <div className="w-full max-w-4xl bg-zinc-900 border-4 border-red-600/80 rounded-2xl shadow-2xl overflow-hidden font-pixel flex flex-col max-h-[92vh]">
        {/* Banner */}
        <div className="bg-red-700 px-6 py-4 flex items-center justify-between text-white border-b-4 border-red-900">
          <div className="flex items-center gap-3">
            <AlertTriangle className="animate-bounce" size={26} />
            <div>
              <h2 className="font-arcade text-sm md:text-base tracking-wider">
                {meeting.cause === 'body'
                  ? `DEAD BODY REPORTED BY ${meeting.reporterName.toUpperCase()}!`
                  : `EMERGENCY MEETING CALLED BY ${meeting.reporterName.toUpperCase()}!`}
              </h2>
              <div className="text-[11px] text-red-200 mt-0.5">
                VOTING TIME: {timeRemaining} SECONDS REMAINING
              </div>
            </div>
          </div>
          <div className="font-arcade text-lg bg-red-900/80 px-3 py-1 rounded border border-red-400">
            {timeRemaining}s
          </div>
        </div>

        {/* Content grid: Crew list & Discussion chat */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 overflow-y-auto flex-1">
          {/* Crewmates Grid */}
          <div className="md:col-span-2 grid grid-cols-2 sm:grid-cols-3 gap-3">
            {characters.map((char) => {
              const isDead = char.state === 'dead' || char.state === 'ghost';
              const hasVotedForThis = selectedTarget === char.id;
              const voteCount = Object.values(meeting.votes).filter(
                (v) => v === char.id
              ).length;

              return (
                <div
                  key={char.id}
                  onClick={() => !isDead && handleVote(char.id)}
                  className={`relative p-3 rounded-xl border-2 flex flex-col items-center justify-between transition-all select-none ${
                    isDead
                      ? 'bg-zinc-950/50 border-zinc-800 opacity-40 cursor-not-allowed'
                      : hasVotedForThis
                      ? 'bg-amber-950/40 border-amber-400 scale-[1.02] shadow-lg cursor-pointer'
                      : 'bg-zinc-800/80 border-zinc-700 hover:border-zinc-400 cursor-pointer'
                  }`}
                >
                  {/* Status Indicator */}
                  {isDead && (
                    <div className="absolute top-2 right-2 text-red-500 font-arcade text-[9px] flex items-center gap-1">
                      <UserX size={12} /> DEAD
                    </div>
                  )}

                  {/* Character Avatar */}
                  <div className="relative my-2">
                    <div
                      className="w-12 h-16 rounded-t-full rounded-b-lg border-2 border-black relative"
                      style={{ backgroundColor: COLOR_MAP[char.color] }}
                    >
                      {/* Visor */}
                      <div className="absolute top-3 left-1.5 w-8 h-4 bg-cyan-200 border border-black rounded-full" />
                      {/* Backpack */}
                      <div
                        className="absolute top-4 -left-2 w-2.5 h-8 rounded border border-black"
                        style={{ backgroundColor: COLOR_MAP[char.color] }}
                      />
                    </div>
                  </div>

                  <div className="text-center w-full">
                    <div className="font-arcade text-[10px] text-zinc-100 truncate">
                      {char.name} {char.isPlayer && '(YOU)'}
                    </div>
                    <div className="text-[10px] text-zinc-400">
                      PING: {char.pingMs}ms
                    </div>
                  </div>

                  {/* Vote count badge */}
                  {votesRevealed && voteCount > 0 && (
                    <div className="absolute -top-2 -left-2 bg-red-600 text-white font-arcade text-[10px] px-2 py-0.5 rounded-full border border-white">
                      {voteCount} VOTES
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* AI Discussion Chat Log */}
          <div className="bg-zinc-950 border-2 border-zinc-800 rounded-xl p-3 flex flex-col justify-between h-full min-h-[220px]">
            <div className="flex items-center gap-2 pb-2 border-b border-zinc-800 font-arcade text-[10px] text-zinc-400">
              <MessageSquare size={12} /> CREW COMM CHATTER
            </div>
            <div className="flex-1 overflow-y-auto space-y-2 py-2 pr-1 text-xs">
              {meeting.chatMessages.map((msg, i) => (
                <div key={i} className="bg-zinc-900 p-2 rounded border border-zinc-800">
                  <span
                    className="font-arcade text-[9px] mr-1.5"
                    style={{ color: COLOR_MAP[msg.color] }}
                  >
                    {msg.senderName}:
                  </span>
                  <span className="text-zinc-300 text-[11px] font-pixel">{msg.text}</span>
                </div>
              ))}
            </div>

            {/* Quick Chat Response for Player */}
            <div className="pt-2 border-t border-zinc-800 flex flex-wrap gap-1">
              <button
                onClick={() => {
                  sound.playUiClick();
                  meeting.chatMessages.push({
                    senderId: player?.id || 'p',
                    senderName: player?.name || 'Player',
                    color: player?.color || 'red',
                    text: 'I was completing the Sonar Pinger task in Navigation!',
                    timestamp: Date.now(),
                  });
                }}
                className="text-[9px] bg-zinc-800 hover:bg-zinc-700 px-2 py-1 rounded text-zinc-300 font-arcade cursor-pointer"
              >
                "I was doing tasks!"
              </button>
              <button
                onClick={() => {
                  sound.playUiClick();
                  meeting.chatMessages.push({
                    senderId: player?.id || 'p',
                    senderName: player?.name || 'Player',
                    color: player?.color || 'red',
                    text: 'Check security cameras or ping latency logs!',
                    timestamp: Date.now(),
                  });
                }}
                className="text-[9px] bg-zinc-800 hover:bg-zinc-700 px-2 py-1 rounded text-zinc-300 font-arcade cursor-pointer"
              >
                "Check cameras!"
              </button>
            </div>
          </div>
        </div>

        {/* Footer controls: Skip Vote & Confirm */}
        <div className="bg-zinc-950 px-6 py-3 border-t-2 border-zinc-800 flex items-center justify-between">
          <button
            onClick={() => handleVote('skip')}
            disabled={hasConfirmedVote}
            className={`px-4 py-2 font-arcade text-xs rounded border transition-colors cursor-pointer ${
              selectedTarget === 'skip'
                ? 'bg-amber-600 border-amber-400 text-white'
                : 'bg-zinc-800 border-zinc-700 text-zinc-300 hover:bg-zinc-700'
            }`}
          >
            SKIP VOTE
          </button>

          <div className="flex items-center gap-3">
            {hasConfirmedVote ? (
              <span className="text-xs text-emerald-400 font-arcade flex items-center gap-1">
                <Check size={14} /> VOTE RECORDED
              </span>
            ) : (
              <span className="text-xs text-amber-400 font-arcade animate-pulse">
                SELECT A CREWMATE TO VOTE
              </span>
            )}

            {!votesRevealed && (
              <button
                onClick={handleRevealVotes}
                className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white font-arcade text-xs rounded border-b-2 border-red-900 cursor-pointer"
              >
                REVEAL TALLY &gt;&gt;
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
