import { useState, useEffect, useRef, useCallback } from 'react';
import {
  Character,
  DeadBody,
  TaskDefinition,
  Vent,
  SabotageState,
  MeetingState,
  GameStatus,
  Role,
  BeanColor,
  HatType,
  RoomId,
} from '../types';
import {
  ROOMS,
  CORRIDORS,
  VENTS,
  TASK_TEMPLATES,
  EMERGENCY_BUTTON,
  isInsideShip,
  getRoomAt,
} from './mapData';
import { sound } from '../audio/soundEngine';

const ALL_COLORS: BeanColor[] = [
  'red',
  'blue',
  'green',
  'pink',
  'orange',
  'yellow',
  'cyan',
  'purple',
  'black',
  'white',
];

const BOT_NAMES = [
  'RedSus',
  'BluBoi',
  'Greenie',
  'Pinky',
  'Nacho',
  'Banana',
  'Cyano',
  'Grape',
  'Shadow',
  'Cloudy',
];

export function useGameLogic() {
  const [status, setStatus] = useState<GameStatus>('title');
  const [playerRolePreference, setPlayerRolePreference] = useState<'random' | 'crewmate' | 'impostor'>('random');
  const [playerColor, setPlayerColor] = useState<BeanColor>('red');
  const [playerHat, setPlayerHat] = useState<HatType>('mario');
  const [playerName, setPlayerName] = useState<string>('Pinger_01');

  const [characters, setCharacters] = useState<Character[]>([]);
  const [deadBodies, setDeadBodies] = useState<DeadBody[]>([]);
  const [activeTask, setActiveTask] = useState<TaskDefinition | null>(null);
  const [adminMapOpen, setAdminMapOpen] = useState(false);
  const [cctvOpen, setCctvOpen] = useState(false);
  const [sabotageOpen, setSabotageOpen] = useState(false);
  const [customizerOpen, setCustomizerOpen] = useState(false);
  const [workspaceOpen, setWorkspaceOpen] = useState(false);

  const [sabotage, setSabotage] = useState<SabotageState>({
    active: 'none',
    countdown: 30,
    fixProgressA: false,
    fixProgressB: false,
  });

  const [meeting, setMeeting] = useState<MeetingState | null>(null);
  const [endGameMessage, setEndGameMessage] = useState<{ title: string; subtitle: string; won: boolean } | null>(null);

  // Movement keys ref
  const keysPressed = useRef<Record<string, boolean>>({});

  // Initialize a new game
  const startNewGame = useCallback((forcedRole?: Role) => {
    sound.playBootChime();
    sound.startChiptuneMusic();

    const assignedRole: Role =
      forcedRole ||
      (playerRolePreference === 'random'
        ? Math.random() < 0.25
          ? 'impostor'
          : 'crewmate'
        : playerRolePreference);

    // Pick 8 bots with distinct colors
    const availableColors = ALL_COLORS.filter((c) => c !== playerColor);
    const chosenColors = availableColors.slice(0, 7);

    // If player is crewmate, randomly pick 1 bot to be impostor
    // If player is impostor, all bots are crewmates
    const impostorBotIdx = assignedRole === 'crewmate' ? Math.floor(Math.random() * chosenColors.length) : -1;

    // Create player tasks
    const playerTasks: TaskDefinition[] = TASK_TEMPLATES.map((t, idx) => ({
      ...t,
      id: `task_player_${idx}`,
      completed: false,
    }));

    const playerChar: Character = {
      id: 'player_0',
      name: playerName || 'Player',
      color: playerColor,
      hat: playerHat,
      role: assignedRole,
      x: 1050 + Math.random() * 80,
      y: 280 + Math.random() * 80,
      vx: 0,
      vy: 0,
      state: 'idle',
      facing: 'right',
      currentRoom: 'cafeteria',
      isPlayer: true,
      tasks: playerTasks,
      aiActionTimer: 0,
      aiCurrentTaskIndex: 0,
      pingMs: Math.floor(Math.random() * 25) + 15,
      killCooldown: 15,
    };

    const botChars: Character[] = chosenColors.map((color, idx) => {
      const isImpostor = idx === impostorBotIdx;
      const botTasks: TaskDefinition[] = TASK_TEMPLATES.slice(0, 4).map((t, tIdx) => ({
        ...t,
        id: `task_bot_${idx}_${tIdx}`,
        completed: false,
      }));

      return {
        id: `bot_${idx}`,
        name: BOT_NAMES[idx] || `Bot_${idx}`,
        color,
        hat: (['none', 'crown', 'sprout', 'halo', 'egg', 'detective'][idx % 6] as HatType),
        role: isImpostor ? 'impostor' : 'crewmate',
        x: 950 + (idx % 4) * 80,
        y: 220 + Math.floor(idx / 4) * 80,
        vx: 0,
        vy: 0,
        state: 'idle',
        facing: 'right',
        currentRoom: 'cafeteria',
        isPlayer: false,
        tasks: botTasks,
        aiActionTimer: Math.random() * 120,
        aiCurrentTaskIndex: 0,
        pingMs: isImpostor ? 180 + Math.floor(Math.random() * 40) : Math.floor(Math.random() * 40) + 20,
        killCooldown: 25,
      };
    });

    setCharacters([playerChar, ...botChars]);
    setDeadBodies([]);
    setActiveTask(null);
    setMeeting(null);
    setEndGameMessage(null);
    setSabotage({
      active: 'none',
      countdown: 30,
      fixProgressA: false,
      fixProgressB: false,
    });

    // Role reveal sequence
    setStatus('role_reveal');
    setTimeout(() => {
      setStatus('playing');
    }, 2800);
  }, [playerColor, playerHat, playerName, playerRolePreference]);

  // Main game loop (60 FPS)
  useEffect(() => {
    if (status !== 'playing') return;

    let animId: number;

    const tick = () => {
      setCharacters((prevChars) => {
        const player = prevChars.find((c) => c.isPlayer);
        if (!player) return prevChars;

        const nextChars = prevChars.map((char) => {
          if (char.state === 'dead') return char;

          if (char.isPlayer) {
            // Player movement
            let dx = 0;
            let dy = 0;
            const speed = 4.2;

            if (keysPressed.current['w'] || keysPressed.current['arrowup']) dy -= speed;
            if (keysPressed.current['s'] || keysPressed.current['arrowdown']) dy += speed;
            if (keysPressed.current['a'] || keysPressed.current['arrowleft']) dx -= speed;
            if (keysPressed.current['d'] || keysPressed.current['arrowright']) dx += speed;

            // Normalize diagonal
            if (dx !== 0 && dy !== 0) {
              dx *= 0.7071;
              dy *= 0.7071;
            }

            const targetX = char.x + dx;
            const targetY = char.y + dy;

            // Collision check: Ghosts can pass through walls; alive player cannot
            const canMoveX = char.state === 'ghost' || isInsideShip(targetX, char.y);
            const canMoveY = char.state === 'ghost' || isInsideShip(char.x, targetY);

            const nextX = canMoveX ? targetX : char.x;
            const nextY = canMoveY ? targetY : char.y;

            // Footsteps
            if ((dx !== 0 || dy !== 0) && Math.random() < 0.08) {
              sound.playFootstep();
            }

            // Kill cooldown decrement
            const nextKillCd = Math.max(0, char.killCooldown - 1 / 60);

            return {
              ...char,
              x: nextX,
              y: nextY,
              vx: dx,
              vy: dy,
              facing: dx < 0 ? 'left' : dx > 0 ? 'right' : char.facing,
              state: (dx !== 0 || dy !== 0 ? 'walking' : 'idle') as Character['state'],
              currentRoom: getRoomAt(nextX, nextY),
              killCooldown: nextKillCd,
            };
          } else {
            // AI Bot Movement & Behavior
            const bot: Character = { ...char };
            bot.aiActionTimer -= 1;
            bot.killCooldown = Math.max(0, bot.killCooldown - 1 / 60);

            // If timer expires, pick next destination
            if (bot.aiActionTimer <= 0) {
              const randomRoom = ROOMS[Math.floor(Math.random() * ROOMS.length)];
              bot.targetX = randomRoom.x + Math.random() * (randomRoom.w - 60) + 30;
              bot.targetY = randomRoom.y + Math.random() * (randomRoom.h - 60) + 30;
              bot.aiActionTimer = 180 + Math.random() * 240; // 3 to 7 seconds dwell
            }

            // Move towards target if exists
            if (bot.targetX !== undefined && bot.targetY !== undefined) {
              const diffX = bot.targetX - bot.x;
              const diffY = bot.targetY - bot.y;
              const dist = Math.hypot(diffX, diffY);

              if (dist > 6) {
                const moveSpeed = 2.4;
                const stepX = (diffX / dist) * moveSpeed;
                const stepY = (diffY / dist) * moveSpeed;

                if (isInsideShip(bot.x + stepX, bot.y + stepY)) {
                  bot.x += stepX;
                  bot.y += stepY;
                  bot.facing = stepX < 0 ? 'left' : 'right';
                  bot.state = 'walking';
                } else {
                  // Stuck on corner, re-roll target
                  bot.aiActionTimer = 0;
                }
              } else {
                bot.state = 'idle';
                // Complete a task if crewmate
                if (bot.role === 'crewmate' && Math.random() < 0.02) {
                  const uncompleted = bot.tasks.find((t) => !t.completed);
                  if (uncompleted) {
                    uncompleted.completed = true;
                  }
                }
              }
            }

            bot.currentRoom = getRoomAt(bot.x, bot.y);

            // AI Impostor logic: stalk and eliminate nearby isolated crewmate if player is not looking!
            if (bot.role === 'impostor' && bot.killCooldown <= 0) {
              const nearbyVictim = prevChars.find(
                (v) =>
                  v.id !== bot.id &&
                  v.state !== 'dead' &&
                  v.state !== 'ghost' &&
                  v.role !== 'impostor' &&
                  Math.hypot(v.x - bot.x, v.y - bot.y) < 55
              );

              if (nearbyVictim) {
                // Eliminate victim!
                sound.trigger('kill_crewmate');
                bot.killCooldown = 28;
                // Add dead body
                setDeadBodies((bodies) => [
                  ...bodies,
                  {
                    id: `body_${Date.now()}`,
                    victimId: nearbyVictim.id,
                    victimName: nearbyVictim.name,
                    color: nearbyVictim.color,
                    x: nearbyVictim.x,
                    y: nearbyVictim.y,
                    room: nearbyVictim.currentRoom,
                    reported: false,
                  },
                ]);

                // Update victim to ghost
                nearbyVictim.state = nearbyVictim.isPlayer ? 'ghost' : 'dead';
              }
            }

            return bot;
          }
        });

        return nextChars;
      });

      // Sabotage countdown
      setSabotage((prev) => {
        if (prev.active === 'reactor' || prev.active === 'o2') {
          const nextCount = prev.countdown - 1 / 60;
          if (nextCount <= 0) {
            // Impostors win by sabotage!
            triggerEndGame(false, 'CRITICAL SABOTAGE FAILURE! IMPOSTOR WINS.');
            return { ...prev, countdown: 0, active: 'none' };
          }
          return { ...prev, countdown: nextCount };
        }
        return prev;
      });

      // Check win/loss conditions
      checkWinConditions();

      animId = requestAnimationFrame(tick);
    };

    animId = requestAnimationFrame(tick);

    return () => cancelAnimationFrame(animId);
  }, [status]);

  // Check Win conditions
  const checkWinConditions = useCallback(() => {
    setCharacters((currentChars) => {
      const player = currentChars.find((c) => c.isPlayer);
      if (!player) return currentChars;

      const aliveImpostors = currentChars.filter(
        (c) => c.role === 'impostor' && c.state !== 'dead' && c.state !== 'ghost'
      );
      const aliveCrewmates = currentChars.filter(
        (c) => c.role === 'crewmate' && c.state !== 'dead' && c.state !== 'ghost'
      );

      // Condition 1: All Impostors dead
      if (aliveImpostors.length === 0) {
        triggerEndGame(
          player.role === 'crewmate',
          'ALL IMPOSTORS EJECTED! CREWMATE VICTORY.'
        );
        return currentChars;
      }

      // Condition 2: Impostors equal or outnumber crewmates
      if (aliveImpostors.length >= aliveCrewmates.length) {
        triggerEndGame(
          player.role === 'impostor',
          'IMPOSTORS HAVE OVERRUN THE SHIP! IMPOSTOR VICTORY.'
        );
        return currentChars;
      }

      // Condition 3: All tasks completed by crewmates
      const allTasks = currentChars.flatMap((c) => (c.role === 'crewmate' ? c.tasks : []));
      const completedTasks = allTasks.filter((t) => t.completed).length;
      if (allTasks.length > 0 && completedTasks >= allTasks.length) {
        triggerEndGame(
          player.role === 'crewmate',
          'TOTAL TASK COMPLETION! CREWMATE VICTORY.'
        );
        return currentChars;
      }

      return currentChars;
    });
  }, []);

  const triggerEndGame = (won: boolean, subtitle: string) => {
    sound.trigger(won ? 'victory' : 'defeat');
    setStatus(won ? 'victory' : 'defeat');
    setEndGameMessage({
      title: won ? 'VICTORY' : 'DEFEAT',
      subtitle,
      won,
    });
  };

  // Keyboard Event Listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key.toLowerCase();
      keysPressed.current[key] = true;

      if (status !== 'playing') return;

      if (key === 'e' || key === ' ') {
        handleInteractButton();
      } else if (key === 'q') {
        handleKillButton();
      } else if (key === 'r') {
        handleReportButton();
      } else if (key === 'v' || key === 'b') {
        handleVentButton();
      } else if (key === 'm') {
        setAdminMapOpen((prev) => !prev);
      } else if (key === 'c') {
        setCctvOpen((prev) => !prev);
      } else if (key === 's') {
        const player = characters.find((c) => c.isPlayer);
        if (player?.role === 'impostor') {
          setSabotageOpen((prev) => !prev);
        }
      } else if (key === 'g') {
        setWorkspaceOpen((prev) => !prev);
      } else if (key === 'escape') {
        setActiveTask(null);
        setAdminMapOpen(false);
        setCctvOpen(false);
        setSabotageOpen(false);
        setWorkspaceOpen(false);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keysPressed.current[e.key.toLowerCase()] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [status, characters]);

  // Player & Entities queries
  const player = characters.find((c) => c.isPlayer) || null;

  // Nearby checks
  const nearbyTask = player
    ? player.tasks.find(
        (t) => !t.completed && Math.hypot(t.x - player.x, t.y - player.y) < 65
      ) || null
    : null;

  const nearbyVent = player && player.role === 'impostor'
    ? VENTS.find((v) => Math.hypot(v.x - player.x, v.y - player.y) < 65) || null
    : null;

  const nearbyBody = player
    ? deadBodies.find((b) => Math.hypot(b.x - player.x, b.y - player.y) < 75) || null
    : null;

  const canEmergency = Boolean(
    player &&
    player.currentRoom === 'cafeteria' &&
    Math.hypot(EMERGENCY_BUTTON.x - player.x, EMERGENCY_BUTTON.y - player.y) < 65 &&
    sabotage.active === 'none'
  );

  const canAccessComms = Boolean(
    player &&
    (player.currentRoom === 'communications' ||
      Math.hypot(1330 - player.x, 1140 - player.y) < 70)
  );

  // Action Handlers
  const handleInteractButton = () => {
    if (!player) return;

    if (nearbyTask) {
      sound.playUiClick();
      setActiveTask(nearbyTask);
    } else if (canAccessComms) {
      sound.playUiClick();
      setWorkspaceOpen(true);
    } else if (canEmergency) {
      sound.trigger('emergency');
      callEmergencyMeeting(player.name, 'button');
    }
  };

  const handleKillButton = () => {
    if (!player || player.role !== 'impostor' || player.killCooldown > 0) return;

    const victim = characters.find(
      (c) =>
        !c.isPlayer &&
        c.state !== 'dead' &&
        c.state !== 'ghost' &&
        c.role !== 'impostor' &&
        Math.hypot(c.x - player.x, c.y - player.y) < 65
    );

    if (victim) {
      sound.trigger('kill_crewmate');

      // Spawn body
      setDeadBodies((prev) => [
        ...prev,
        {
          id: `body_${Date.now()}`,
          victimId: victim.id,
          victimName: victim.name,
          color: victim.color,
          x: victim.x,
          y: victim.y,
          room: victim.currentRoom,
          reported: false,
        },
      ]);

      // Eliminate bot
      setCharacters((prev) =>
        prev.map((c) =>
          c.id === victim.id
            ? { ...c, state: 'dead' }
            : c.id === player.id
            ? { ...c, killCooldown: 25 }
            : c
        )
      );
    }
  };

  const handleReportButton = () => {
    if (nearbyBody && player) {
      sound.trigger('report_body');
      callEmergencyMeeting(player.name, 'body', nearbyBody.victimName);
    }
  };

  const handleVentButton = () => {
    if (!player || player.role !== 'impostor' || !nearbyVent) return;

    sound.trigger('vent');
    // Transport to connected vent
    const nextVentId = nearbyVent.connectedVentIds[0];
    const targetVent = VENTS.find((v) => v.id === nextVentId);

    if (targetVent) {
      setCharacters((prev) =>
        prev.map((c) =>
          c.id === player.id
            ? {
                ...c,
                x: targetVent.x,
                y: targetVent.y,
                currentRoom: targetVent.room,
              }
            : c
        )
      );
    }
  };

  // Calling an Emergency Meeting
  const callEmergencyMeeting = (
    reporterName: string,
    cause: 'body' | 'button',
    victimName?: string
  ) => {
    // Generate AI chats
    const aliveBots = characters.filter((c) => !c.isPlayer && c.state !== 'dead' && c.state !== 'ghost');
    const chatter: MeetingState['chatMessages'] = [];

    if (cause === 'body') {
      chatter.push({
        senderId: 'reporter',
        senderName: reporterName,
        color: player?.color || 'red',
        text: `Found ${victimName || 'someone'} in ${player?.currentRoom.toUpperCase() || 'corridor'}!`,
        timestamp: Date.now(),
      });
    } else {
      chatter.push({
        senderId: 'reporter',
        senderName: reporterName,
        color: player?.color || 'red',
        text: 'Emergency Meeting called! Someone has been acting extremely sus!',
        timestamp: Date.now(),
      });
    }

    aliveBots.slice(0, 3).forEach((b) => {
      const suspicions = [
        `I was doing tasks in ${b.currentRoom.toUpperCase()}`,
        `Did anyone check security camera logs?`,
        `I noticed ping latency spiking around ${b.currentRoom}!`,
        `Skip vote for now unless we have proof.`,
      ];
      chatter.push({
        senderId: b.id,
        senderName: b.name,
        color: b.color,
        text: suspicions[Math.floor(Math.random() * suspicions.length)],
        timestamp: Date.now() + 500,
      });
    });

    // Populate simulated AI votes
    const aiVotes: Record<string, string> = {};
    aliveBots.forEach((b) => {
      // 30% chance to vote randomly, 70% chance to skip
      if (Math.random() < 0.35) {
        const potentialTargets = characters.filter((c) => c.state !== 'dead' && c.state !== 'ghost');
        const picked = potentialTargets[Math.floor(Math.random() * potentialTargets.length)];
        aiVotes[b.id] = picked.id;
      } else {
        aiVotes[b.id] = 'skip';
      }
    });

    setMeeting({
      reporterName,
      cause,
      victimName,
      discussionTimeLeft: 20,
      votes: aiVotes,
      hasVoted: false,
      chatMessages: chatter,
    });

    setStatus('meeting');
  };

  const castVote = (voterId: string, targetId: string) => {
    if (!meeting) return;
    sound.trigger('vote_cast');
    setMeeting((prev) =>
      prev
        ? {
            ...prev,
            hasVoted: true,
            votes: { ...prev.votes, [voterId]: targetId },
          }
        : null
    );
  };

  const closeMeeting = () => {
    sound.trigger('modal_close');
    setStatus('playing');
    setMeeting(null);
    setDeadBodies([]); // Clean reported bodies
    checkWinConditions();
  };

  // Task completion
  const handleCompleteCurrentTask = () => {
    if (!activeTask || !player) return;
    sound.trigger('task_complete');
    setCharacters((prev) =>
      prev.map((c) =>
        c.isPlayer
          ? {
              ...c,
              tasks: c.tasks.map((t) =>
                t.id === activeTask.id ? { ...t, completed: true } : t
              ),
            }
          : c
      )
    );
    setActiveTask(null);
    checkWinConditions();
  };

  // Sabotage triggering
  const triggerSabotage = (type: SabotageState['active']) => {
    setSabotage({
      active: type,
      countdown: 30,
      fixProgressA: false,
      fixProgressB: false,
    });
  };

  // Virtual D-pad directional input for touch and on-screen joypad
  const setVirtualKey = (key: string, pressed: boolean) => {
    keysPressed.current[key.toLowerCase()] = pressed;
  };

  return {
    status,
    setStatus,
    playerRolePreference,
    setPlayerRolePreference,
    playerColor,
    setPlayerColor,
    playerHat,
    setPlayerHat,
    playerName,
    setPlayerName,
    characters,
    deadBodies,
    player,
    activeTask,
    setActiveTask,
    nearbyTask,
    nearbyVent,
    nearbyBody,
    canEmergency,
    canAccessComms,
    adminMapOpen,
    setAdminMapOpen,
    cctvOpen,
    setCctvOpen,
    sabotageOpen,
    setSabotageOpen,
    customizerOpen,
    setCustomizerOpen,
    workspaceOpen,
    setWorkspaceOpen,
    sabotage,
    triggerSabotage,
    meeting,
    endGameMessage,
    startNewGame,
    handleInteractButton,
    handleKillButton,
    handleReportButton,
    handleVentButton,
    callEmergencyMeeting,
    castVote,
    closeMeeting,
    handleCompleteCurrentTask,
    setVirtualKey,
  };
}
