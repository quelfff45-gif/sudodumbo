import React, { useEffect, useState } from 'react';
import { sound } from '../audio/soundEngine';
import { Sparkles, Film, Award, Star } from 'lucide-react';

interface StudioIntroProps {
  onFinish: () => void;
}

export const StudioIntro: React.FC<StudioIntroProps> = ({ onFinish }) => {
  const [stage, setStage] = useState<'fade_in' | 'reveal' | 'fade_out'>('fade_in');

  useEffect(() => {
    sound.playStudioIntroJingle();

    const t1 = setTimeout(() => {
      setStage('reveal');
    }, 600);

    const t2 = setTimeout(() => {
      setStage('fade_out');
    }, 2400);

    const t3 = setTimeout(() => {
      onFinish();
    }, 3000);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [onFinish]);

  const handleSkip = () => {
    sound.playUiClick();
    onFinish();
  };

  return (
    <div
      onClick={handleSkip}
      className={`relative w-full h-full bg-black text-zinc-100 flex flex-col items-center justify-center p-6 cursor-pointer select-none font-arcade transition-opacity duration-500 ${
        stage === 'fade_out' ? 'opacity-0' : 'opacity-100'
      }`}
    >
      {/* Subtle CRT scanline backdrop */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-amber-950/20 via-black to-black pointer-events-none" />

      {/* Retro Golden Studio Emblem */}
      <div className="z-10 flex flex-col items-center gap-5 text-center max-w-xl">
        {/* Emblem Shield / Laurel */}
        <div className="relative flex items-center justify-center">
          <div className="w-24 h-24 rounded-2xl border-4 border-amber-400 bg-gradient-to-br from-amber-600/30 to-amber-950/80 shadow-[0_0_35px_rgba(245,158,11,0.5)] flex items-center justify-center relative">
            {/* Corner rivets */}
            <div className="absolute top-1.5 left-1.5 w-1.5 h-1.5 rounded-full bg-amber-200" />
            <div className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-amber-200" />
            <div className="absolute bottom-1.5 left-1.5 w-1.5 h-1.5 rounded-full bg-amber-200" />
            <div className="absolute bottom-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-amber-200" />

            {/* Monogram / Icon */}
            <div className="flex flex-col items-center text-amber-300">
              <span className="text-2xl font-bold tracking-tighter">RJ</span>
              <div className="flex gap-1 mt-1 text-amber-400">
                <Star size={10} className="fill-amber-400" />
                <Star size={10} className="fill-amber-400" />
                <Star size={10} className="fill-amber-400" />
              </div>
            </div>
          </div>

          <Sparkles className="absolute -top-3 -right-3 text-amber-300 animate-spin" size={24} />
        </div>

        {/* Studio Name Title */}
        <div className="space-y-2">
          <div className="text-[10px] text-amber-400/90 tracking-[0.25em] font-pixel uppercase">
            A PRODUCTION OF
          </div>
          <h1 className="text-xl sm:text-2xl md:text-3xl text-amber-300 tracking-wider drop-shadow-[0_4px_16px_rgba(245,158,11,0.6)]">
            ROMAN JAMES
          </h1>
          <h2 className="text-sm sm:text-lg text-amber-400 tracking-[0.35em] drop-shadow-[0_2px_8px_rgba(245,158,11,0.4)]">
            PRODUCTIONS
          </h2>
        </div>

        {/* Presents kicker */}
        <div className="mt-4">
          <span className="text-xs sm:text-sm text-zinc-300 tracking-[0.4em] font-pixel animate-pulse">
            PRESENTS
          </span>
        </div>

        {/* Official licensing badge */}
        <div className="mt-6 pt-4 border-t border-zinc-800/80 flex items-center gap-3 text-[9px] text-zinc-500 font-pixel">
          <span>LICENSED BY NINTENDO</span>
          <span>·</span>
          <span>ORIGINAL ENTERTAINMENT</span>
        </div>
      </div>

      {/* Skip cue */}
      <div className="absolute bottom-4 text-[8px] text-zinc-600 font-pixel">
        CLICK OR PRESS [A] TO SKIP INTRO
      </div>
    </div>
  );
};
