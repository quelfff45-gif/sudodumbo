import React, { useState, useEffect, useRef } from 'react';
import { TaskDefinition } from '../types';
import { sound } from '../audio/soundEngine';
import { X, Sparkles, CheckCircle2, RotateCcw, Crosshair } from 'lucide-react';

interface TaskModalProps {
  task: TaskDefinition;
  onComplete: () => void;
  onClose: () => void;
}

export const TaskModal: React.FC<TaskModalProps> = ({ task, onComplete, onClose }) => {
  useEffect(() => {
    sound.trigger('modal_open');
  }, []);

  const handleClose = () => {
    sound.trigger('modal_close');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-lg bg-zinc-900 border-4 border-zinc-700 rounded-xl shadow-2xl overflow-hidden font-pixel text-zinc-100">
        {/* Top retro bar */}
        <div className="flex items-center justify-between bg-zinc-800 px-4 py-3 border-b-2 border-zinc-700">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
            <span className="font-arcade text-xs text-amber-400 tracking-wider">
              {task.name.toUpperCase()}
            </span>
          </div>
          <button
            onClick={handleClose}
            className="text-zinc-400 hover:text-white p-1 hover:bg-zinc-700 rounded transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Task minigame content */}
        <div className="p-6 bg-zinc-950 flex flex-col items-center justify-center min-h-[360px]">
          {task.type === 'sonar_pinger' && (
            <SonarPingerTask onComplete={onComplete} />
          )}
          {task.type === 'fix_wiring' && (
            <WiringTask onComplete={onComplete} />
          )}
          {task.type === 'swipe_card' && (
            <CardSwipeTask onComplete={onComplete} />
          )}
          {task.type === 'clear_asteroids' && (
            <AsteroidsTask onComplete={onComplete} />
          )}
          {task.type === 'medbay_scan' && (
            <MedBayScanTask onComplete={onComplete} />
          )}
          {task.type === 'divert_power' && (
            <DivertPowerTask onComplete={onComplete} />
          )}
        </div>
      </div>
    </div>
  );
};

/**
 * 1. THE SONAR PINGER TASK (Calibrate radar ping)
 */
const SonarPingerTask: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [pingsCalibrated, setPingsCalibrated] = useState(0);
  const [currentPingMs, setCurrentPingMs] = useState(840);
  const [angle, setAngle] = useState(0);
  const [targetAngle, setTargetAngle] = useState(90);
  const [feedback, setFeedback] = useState<string>('LOCK ON TARGET BEACON & PING!');

  useEffect(() => {
    const timer = setInterval(() => {
      setAngle((prev) => (prev + 3) % 360);
    }, 25);
    return () => clearInterval(timer);
  }, []);

  const handlePing = () => {
    sound.playSonarPing(false);
    const diff = Math.abs(angle - targetAngle);
    if (diff < 35 || diff > 325) {
      sound.playSonarPing(true);
      const next = pingsCalibrated + 1;
      setPingsCalibrated(next);
      const nextPing = Math.max(16, Math.floor(currentPingMs / 2.8));
      setCurrentPingMs(nextPing);
      setFeedback(`PING LOCKED! (${nextPing}ms)`);
      setTargetAngle(Math.floor(Math.random() * 320) + 20);

      if (next >= 3) {
        sound.playTaskComplete();
        setFeedback('SONAR CALIBRATED: 18ms (OPTIMAL)');
        setTimeout(onComplete, 900);
      }
    } else {
      setFeedback('MISSED PULSE! TIME THE SWEEP');
    }
  };

  return (
    <div className="flex flex-col items-center gap-4 w-full">
      <div className="relative w-64 h-64 rounded-full border-4 border-emerald-500/80 bg-zinc-950 overflow-hidden flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.2)]">
        {/* Radar Rings */}
        <div className="absolute inset-4 rounded-full border border-emerald-500/30" />
        <div className="absolute inset-12 rounded-full border border-emerald-500/40" />
        <div className="absolute inset-20 rounded-full border border-emerald-500/50" />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-full h-px bg-emerald-500/30" />
        </div>
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="h-full w-px bg-emerald-500/30" />
        </div>

        {/* Sonar sweep line */}
        <div
          className="absolute top-1/2 left-1/2 w-32 h-1 bg-gradient-to-r from-emerald-500 to-transparent origin-left pointer-events-none"
          style={{ transform: `rotate(${angle}deg)` }}
        />

        {/* Target Beacon */}
        <div
          className="absolute top-1/2 left-1/2 w-4 h-4 rounded-full bg-amber-400 border-2 border-white animate-ping origin-center"
          style={{
            transform: `rotate(${targetAngle}deg) translate(80px) rotate(-${targetAngle}deg)`,
          }}
        />
        <div
          className="absolute top-1/2 left-1/2 w-4 h-4 rounded-full bg-amber-400 border-2 border-white origin-center"
          style={{
            transform: `rotate(${targetAngle}deg) translate(80px) rotate(-${targetAngle}deg)`,
          }}
        />

        {/* Center dot */}
        <div className="w-3 h-3 bg-emerald-400 rounded-full z-10" />
      </div>

      <div className="flex flex-col items-center gap-1">
        <div className="font-arcade text-xs text-emerald-400">
          PING LATENCY: <span className="text-amber-400">{currentPingMs}ms</span>
        </div>
        <div className="text-xs text-zinc-400">{feedback}</div>
        <div className="flex gap-2 mt-1">
          {[0, 1, 2].map((idx) => (
            <div
              key={idx}
              className={`w-4 h-4 rounded border ${
                idx < pingsCalibrated
                  ? 'bg-emerald-500 border-emerald-400'
                  : 'bg-zinc-800 border-zinc-700'
              }`}
            />
          ))}
        </div>
      </div>

      <button
        onClick={handlePing}
        disabled={pingsCalibrated >= 3}
        className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 text-white font-arcade text-xs rounded border-b-4 border-emerald-800 transition-all uppercase tracking-wider cursor-pointer"
      >
        [A] TRANSMIT PING PULSE
      </button>
    </div>
  );
};

/**
 * 2. FIX WIRING TASK
 */
const WIRE_COLORS = [
  { id: 'red', hex: '#ef4444', label: 'RED' },
  { id: 'blue', hex: '#3b82f6', label: 'BLUE' },
  { id: 'yellow', hex: '#eab308', label: 'YELLOW' },
  { id: 'pink', hex: '#ec4899', label: 'PINK' },
];

const WiringTask: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [selectedLeft, setSelectedLeft] = useState<string | null>(null);
  const [connected, setConnected] = useState<Record<string, string>>({});
  // Shuffled right order
  const [rightOrder] = useState<string[]>(() =>
    [...WIRE_COLORS.map((w) => w.id)].sort(() => Math.random() - 0.5)
  );

  const handleSelectLeft = (color: string) => {
    sound.playUiClick();
    setSelectedLeft(color);
  };

  const handleSelectRight = (color: string) => {
    if (!selectedLeft) return;
    if (selectedLeft === color) {
      sound.playWireSnap();
      const updated = { ...connected, [selectedLeft]: color };
      setConnected(updated);
      setSelectedLeft(null);

      if (Object.keys(updated).length === WIRE_COLORS.length) {
        sound.playTaskComplete();
        setTimeout(onComplete, 800);
      }
    } else {
      sound.playCardBeep(false);
      setSelectedLeft(null);
    }
  };

  return (
    <div className="w-full flex flex-col items-center gap-6">
      <div className="font-arcade text-xs text-zinc-400">
        MATCH CONNECTORS BY COLOR
      </div>

      <div className="flex justify-between items-center w-full max-w-sm px-4">
        {/* Left Terminals */}
        <div className="flex flex-col gap-6">
          {WIRE_COLORS.map((w) => {
            const isConn = !!connected[w.id];
            const isSelected = selectedLeft === w.id;
            return (
              <button
                key={w.id}
                onClick={() => handleSelectLeft(w.id)}
                disabled={isConn}
                className={`flex items-center gap-2 px-3 py-2 rounded border-2 transition-all cursor-pointer ${
                  isSelected
                    ? 'border-white scale-105'
                    : isConn
                    ? 'border-emerald-500 opacity-60'
                    : 'border-zinc-700 hover:border-zinc-500'
                }`}
                style={{ backgroundColor: `${w.hex}33` }}
              >
                <div
                  className="w-4 h-4 rounded-full border border-white"
                  style={{ backgroundColor: w.hex }}
                />
                <span className="font-arcade text-[10px]" style={{ color: w.hex }}>
                  {w.label}
                </span>
              </button>
            );
          })}
        </div>

        {/* Center Indicator */}
        <div className="flex flex-col items-center gap-1 text-zinc-600 font-lcd text-lg">
          {Object.keys(connected).length}/{WIRE_COLORS.length}
        </div>

        {/* Right Terminals */}
        <div className="flex flex-col gap-6">
          {rightOrder.map((colorId) => {
            const w = WIRE_COLORS.find((item) => item.id === colorId)!;
            const isConn = Object.values(connected).includes(colorId);
            return (
              <button
                key={colorId}
                onClick={() => handleSelectRight(colorId)}
                disabled={isConn}
                className={`flex items-center gap-2 px-3 py-2 rounded border-2 transition-all cursor-pointer ${
                  isConn
                    ? 'border-emerald-500 opacity-60'
                    : 'border-zinc-700 hover:border-zinc-500'
                }`}
                style={{ backgroundColor: `${w.hex}33` }}
              >
                <span className="font-arcade text-[10px]" style={{ color: w.hex }}>
                  {w.label}
                </span>
                <div
                  className="w-4 h-4 rounded-full border border-white"
                  style={{ backgroundColor: w.hex }}
                />
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

/**
 * 3. SWIPE CARD TASK
 */
const CardSwipeTask: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [status, setStatus] = useState<string>('PLEASE SWIPE CARD');
  const [sliderPos, setSliderPos] = useState(0);
  const startTimeRef = useRef<number | null>(null);

  const handleStart = () => {
    startTimeRef.current = Date.now();
  };

  const handleDrag = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value);
    setSliderPos(val);
    if (val >= 98 && startTimeRef.current) {
      const elapsed = Date.now() - startTimeRef.current;
      startTimeRef.current = null;
      if (elapsed < 280) {
        sound.playCardBeep(false);
        setStatus('TOO FAST. RETRY.');
        setSliderPos(0);
      } else if (elapsed > 1100) {
        sound.playCardBeep(false);
        setStatus('TOO SLOW. RETRY.');
        setSliderPos(0);
      } else {
        sound.playCardBeep(true);
        setStatus('ACCEPTED. THANK YOU!');
        sound.playTaskComplete();
        setTimeout(onComplete, 900);
      }
    }
  };

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-sm">
      <div className="w-full bg-zinc-900 border-2 border-zinc-700 rounded-lg p-4 flex flex-col items-center gap-3">
        {/* Card visual */}
        <div className="w-64 h-36 bg-gradient-to-br from-amber-500 to-amber-700 rounded-lg border-2 border-amber-300 p-3 shadow-lg flex flex-col justify-between text-zinc-950 font-arcade">
          <div className="flex justify-between items-center text-[10px]">
            <span>MEMBER ID</span>
            <span>NO. 042</span>
          </div>
          <div className="w-full h-6 bg-zinc-900 rounded opacity-80" />
          <div className="text-[9px] tracking-tighter">
            CREWMATE IDENTIFICATION CARD
          </div>
        </div>

        {/* Reader slot */}
        <div className="w-full bg-zinc-950 border-2 border-zinc-800 rounded p-3 flex flex-col gap-2">
          <div className="font-arcade text-xs text-center text-amber-400">
            {status}
          </div>
          <input
            type="range"
            min="0"
            max="100"
            value={sliderPos}
            onMouseDown={handleStart}
            onTouchStart={handleStart}
            onChange={handleDrag}
            className="w-full accent-amber-400 cursor-ew-resize h-4 bg-zinc-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-zinc-500 font-pixel">
            <span>START</span>
            <span>SWIPE DIRECTION &gt;&gt;&gt;</span>
            <span>END</span>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * 4. CLEAR ASTEROIDS (WEAPONS)
 */
interface Asteroid {
  id: number;
  x: number;
  y: number;
  size: number;
  speed: number;
}

const AsteroidsTask: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [destroyed, setDestroyed] = useState(0);
  const [asteroids, setAsteroids] = useState<Asteroid[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Spawn initial asteroids
    const initial: Asteroid[] = Array.from({ length: 5 }, (_, i) => ({
      id: i,
      x: Math.random() * 240 + 20,
      y: Math.random() * 180 + 20,
      size: Math.random() * 20 + 20,
      speed: Math.random() * 1 + 0.5,
    }));
    setAsteroids(initial);

    const interval = setInterval(() => {
      setAsteroids((prev) =>
        prev.map((ast) => ({
          ...ast,
          x: ast.x + ast.speed > 280 ? -20 : ast.x + ast.speed,
        }))
      );
    }, 40);

    return () => clearInterval(interval);
  }, []);

  const shootAsteroid = (id: number) => {
    sound.playLaser();
    sound.playExplosion();
    const nextCount = destroyed + 1;
    setDestroyed(nextCount);

    setAsteroids((prev) =>
      prev.map((ast) =>
        ast.id === id
          ? {
              ...ast,
              x: -20,
              y: Math.random() * 200 + 20,
              size: Math.random() * 20 + 20,
            }
          : ast
      )
    );

    if (nextCount >= 10) {
      sound.playTaskComplete();
      setTimeout(onComplete, 800);
    }
  };

  return (
    <div className="flex flex-col items-center gap-3 w-full">
      <div className="font-arcade text-xs text-red-400">
        DESTROYED: {destroyed} / 10 ASTEROIDS
      </div>
      <div
        ref={containerRef}
        className="relative w-72 h-64 bg-zinc-950 border-4 border-red-900 rounded-lg overflow-hidden cursor-crosshair shadow-inner"
      >
        {/* Reticle Overlay */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-20">
          <div className="w-full h-px bg-red-500" />
          <div className="h-full w-px bg-red-500 absolute" />
          <div className="w-32 h-32 rounded-full border border-red-500 absolute" />
        </div>

        {/* Asteroids */}
        {asteroids.map((ast) => (
          <button
            key={ast.id}
            onClick={() => shootAsteroid(ast.id)}
            style={{
              left: `${ast.x}px`,
              top: `${ast.y}px`,
              width: `${ast.size}px`,
              height: `${ast.size}px`,
            }}
            className="absolute bg-zinc-600 border-2 border-zinc-400 rounded-md rotate-12 hover:border-amber-400 active:scale-125 transition-transform cursor-pointer"
          />
        ))}
      </div>
      <div className="text-[10px] text-zinc-500">
        CLICK TARGETS TO FIRE SHIP LASER CANNON
      </div>
    </div>
  );
};

/**
 * 5. MEDBAY SCAN
 */
const MedBayScanTask: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    sound.playSonarPing(true);
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          sound.playTaskComplete();
          setTimeout(onComplete, 800);
          return 100;
        }
        return prev + 5;
      });
    }, 150);
    return () => clearInterval(interval);
  }, [onComplete]);

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-sm">
      <div className="relative w-48 h-56 bg-zinc-900 border-2 border-cyan-500/50 rounded-xl overflow-hidden flex flex-col items-center justify-center">
        {/* Holographic scanning line */}
        <div
          className="absolute left-0 right-0 h-1 bg-cyan-400 shadow-[0_0_12px_#22d3ee]"
          style={{ top: `${progress}%` }}
        />
        {/* Bean silhouette */}
        <div className="w-20 h-28 bg-cyan-500/20 border-2 border-cyan-400/60 rounded-t-3xl rounded-b-xl flex items-center justify-center">
          <div className="w-12 h-6 bg-cyan-200/40 rounded-full" />
        </div>
      </div>

      <div className="w-full flex flex-col gap-2 font-arcade text-xs">
        <div className="flex justify-between text-cyan-400">
          <span>SCANNING CREWMATE...</span>
          <span>{progress}%</span>
        </div>
        <div className="w-full h-3 bg-zinc-800 rounded overflow-hidden">
          <div
            className="h-full bg-cyan-500 transition-all duration-150"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="text-[10px] text-zinc-500 flex justify-between">
          <span>WEIGHT: 92 LBS</span>
          <span>BLOOD: O-POS</span>
          <span>STATUS: NORMAL</span>
        </div>
      </div>
    </div>
  );
};

/**
 * 6. DIVERT POWER TASK
 */
const DivertPowerTask: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [switches, setSwitches] = useState([false, false, false, false]);

  const toggle = (idx: number) => {
    sound.playUiClick();
    const copy = [...switches];
    copy[idx] = !copy[idx];
    setSwitches(copy);

    if (copy.every(Boolean)) {
      sound.playWireSnap();
      sound.playTaskComplete();
      setTimeout(onComplete, 800);
    }
  };

  return (
    <div className="flex flex-col items-center gap-6 w-full max-w-sm">
      <div className="font-arcade text-xs text-amber-400 text-center">
        DIVERT POWER ROUTERS TO ONLINE STATUS
      </div>

      <div className="grid grid-cols-4 gap-4 w-full">
        {switches.map((on, idx) => (
          <button
            key={idx}
            onClick={() => toggle(idx)}
            className={`flex flex-col items-center justify-between h-32 p-3 rounded-lg border-2 cursor-pointer transition-all ${
              on
                ? 'bg-emerald-950/60 border-emerald-500'
                : 'bg-zinc-900 border-zinc-700 hover:border-zinc-500'
            }`}
          >
            <span
              className={`w-3 h-3 rounded-full ${
                on ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]' : 'bg-red-500'
              }`}
            />
            <div
              className={`w-6 h-12 rounded bg-zinc-800 border flex items-center justify-center transition-transform ${
                on ? '-translate-y-2 border-emerald-400' : 'translate-y-2 border-zinc-600'
              }`}
            >
              <div className="w-2 h-4 bg-zinc-400 rounded" />
            </div>
            <span className="font-arcade text-[9px] text-zinc-400">CH {idx + 1}</span>
          </button>
        ))}
      </div>
    </div>
  );
};
