import React from 'react';
import { BeanColor, HatType } from '../types';
import { sound } from '../audio/soundEngine';
import { X, Sparkles, Check } from 'lucide-react';

interface CustomizerModalProps {
  currentColor: BeanColor;
  currentHat: HatType;
  playerName: string;
  onUpdate: (color: BeanColor, hat: HatType, name: string) => void;
  onClose: () => void;
}

const COLORS: { id: BeanColor; hex: string; label: string }[] = [
  { id: 'red', hex: '#ef4444', label: 'Red' },
  { id: 'blue', hex: '#3b82f6', label: 'Blue' },
  { id: 'green', hex: '#22c55e', label: 'Green' },
  { id: 'pink', hex: '#ec4899', label: 'Pink' },
  { id: 'orange', hex: '#f97316', label: 'Orange' },
  { id: 'yellow', hex: '#eab308', label: 'Yellow' },
  { id: 'cyan', hex: '#06b6d4', label: 'Cyan' },
  { id: 'purple', hex: '#a855f7', label: 'Purple' },
  { id: 'black', hex: '#334155', label: 'Black' },
  { id: 'white', hex: '#f8fafc', label: 'White' },
];

const HATS: { id: HatType; label: string; icon: string }[] = [
  { id: 'none', label: 'No Hat', icon: '—' },
  { id: 'mario', label: 'Mario Cap', icon: '🧢' },
  { id: 'crown', label: 'Royal Crown', icon: '👑' },
  { id: 'sprout', label: 'Plant Sprout', icon: '🌱' },
  { id: 'halo', label: 'Angel Halo', icon: '😇' },
  { id: 'egg', label: 'Fried Egg', icon: '🍳' },
  { id: 'detective', label: 'Detective', icon: '🕵️' },
  { id: 'goggles', label: 'Space Goggles', icon: '🥽' },
];

export const CustomizerModal: React.FC<CustomizerModalProps> = ({
  currentColor,
  currentHat,
  playerName,
  onUpdate,
  onClose,
}) => {
  const [selectedColor, setSelectedColor] = React.useState(currentColor);
  const [selectedHat, setSelectedHat] = React.useState(currentHat);
  const [name, setName] = React.useState(playerName);

  React.useEffect(() => {
    sound.trigger('modal_open');
  }, []);

  const handleClose = () => {
    sound.trigger('modal_close');
    onClose();
  };

  const handleSave = () => {
    sound.trigger('task_complete');
    onUpdate(selectedColor, selectedHat, name.trim() || 'Player');
    onClose();
  };

  const activeColorHex = COLORS.find((c) => c.id === selectedColor)?.hex || '#ef4444';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-xl bg-zinc-900 border-4 border-amber-500 rounded-2xl overflow-hidden font-pixel text-zinc-100 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between bg-zinc-800 px-4 py-3 border-b-2 border-zinc-700">
          <div className="flex items-center gap-2">
            <Sparkles className="text-amber-400" size={18} />
            <span className="font-arcade text-xs text-amber-400 tracking-wider">
              CREWMATE WARDROBE (CUSTOMIZE)
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1 hover:bg-zinc-700 rounded transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 flex flex-col md:flex-row gap-6 items-center">
          {/* Avatar Preview */}
          <div className="w-48 h-60 bg-zinc-950 border-2 border-zinc-800 rounded-xl flex flex-col items-center justify-center relative shadow-inner">
            {/* Hat */}
            <div className="text-3xl mb-[-12px] z-10 select-none">
              {HATS.find((h) => h.id === selectedHat)?.icon}
            </div>

            {/* Bean Body */}
            <div
              className="w-20 h-28 rounded-t-full rounded-b-xl border-4 border-black relative transition-colors duration-200"
              style={{ backgroundColor: activeColorHex }}
            >
              {/* Visor */}
              <div className="absolute top-5 left-3 w-12 h-6 bg-cyan-200 border-2 border-black rounded-full" />
              {/* Backpack */}
              <div
                className="absolute top-6 -left-3.5 w-4 h-14 rounded border-2 border-black"
                style={{ backgroundColor: activeColorHex }}
              />
            </div>

            <div className="mt-3 font-arcade text-xs text-zinc-300">
              {name || 'Player'}
            </div>
          </div>

          {/* Controls */}
          <div className="flex-1 w-full space-y-4">
            <div>
              <label className="font-arcade text-[10px] text-zinc-400 block mb-1">
                PLAYER CODENAME
              </label>
              <input
                type="text"
                value={name}
                maxLength={10}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 rounded px-3 py-2 font-arcade text-xs text-amber-400 focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="font-arcade text-[10px] text-zinc-400 block mb-1">
                SPACESUIT COLOR
              </label>
              <div className="grid grid-cols-5 gap-2">
                {COLORS.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => {
                      sound.playUiClick();
                      setSelectedColor(c.id);
                    }}
                    style={{ backgroundColor: c.hex }}
                    className={`h-8 rounded-lg border-2 transition-transform cursor-pointer ${
                      selectedColor === c.id
                        ? 'border-white scale-110 shadow-md ring-2 ring-amber-400'
                        : 'border-black hover:scale-105'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div>
              <label className="font-arcade text-[10px] text-zinc-400 block mb-1">
                NINTENDO HATS &amp; GEAR
              </label>
              <div className="grid grid-cols-4 gap-2">
                {HATS.map((h) => (
                  <button
                    key={h.id}
                    onClick={() => {
                      sound.playUiClick();
                      setSelectedHat(h.id);
                    }}
                    className={`p-2 rounded-lg border flex flex-col items-center justify-center transition-all cursor-pointer ${
                      selectedHat === h.id
                        ? 'bg-amber-950/60 border-amber-400 text-amber-300'
                        : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-600'
                    }`}
                  >
                    <span className="text-xl">{h.icon}</span>
                    <span className="font-arcade text-[8px] mt-1 truncate w-full text-center">
                      {h.label.split(' ')[0]}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-zinc-950 px-6 py-3 border-t-2 border-zinc-800 flex justify-end">
          <button
            onClick={handleSave}
            className="px-6 py-2.5 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-arcade text-xs rounded border-b-4 border-amber-800 cursor-pointer uppercase transition-all"
          >
            [A] SAVE &amp; EQUIP
          </button>
        </div>
      </div>
    </div>
  );
};
