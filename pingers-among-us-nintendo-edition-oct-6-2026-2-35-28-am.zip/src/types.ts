/**
 * Core type definitions for Pingers: Among Us - Nintendo Edition
 */

export type Role = 'crewmate' | 'impostor';

export type GameStatus =
  | 'title'
  | 'role_reveal'
  | 'playing'
  | 'meeting'
  | 'ejection'
  | 'victory'
  | 'defeat';

export type RoomId =
  | 'cafeteria'
  | 'weapons'
  | 'navigation'
  | 'shields'
  | 'communications'
  | 'storage'
  | 'admin'
  | 'electrical'
  | 'medbay'
  | 'security'
  | 'reactor'
  | 'hallway';

export type TaskType =
  | 'sonar_pinger'
  | 'fix_wiring'
  | 'swipe_card'
  | 'clear_asteroids'
  | 'medbay_scan'
  | 'divert_power';

export interface TaskDefinition {
  id: string;
  type: TaskType;
  name: string;
  room: RoomId;
  x: number;
  y: number;
  completed: boolean;
}

export type BeanColor =
  | 'red'
  | 'blue'
  | 'green'
  | 'pink'
  | 'orange'
  | 'yellow'
  | 'black'
  | 'white'
  | 'purple'
  | 'cyan';

export type HatType =
  | 'mario'
  | 'crown'
  | 'sprout'
  | 'halo'
  | 'egg'
  | 'goggles'
  | 'detective'
  | 'none';

export interface Character {
  id: string;
  name: string;
  color: BeanColor;
  hat: HatType;
  role: Role;
  x: number;
  y: number;
  vx: number;
  vy: number;
  targetX?: number;
  targetY?: number;
  state: 'idle' | 'walking' | 'venting' | 'dead' | 'ghost';
  facing: 'left' | 'right';
  currentRoom: RoomId;
  isPlayer: boolean;
  tasks: TaskDefinition[];
  aiActionTimer: number;
  aiCurrentTaskIndex: number;
  aiDestinationRoom?: RoomId;
  lastSeenRoom?: RoomId;
  sawSuspiciousOf?: string;
  pingMs: number; // The "pinger" latency metric!
  killCooldown: number;
}

export interface DeadBody {
  id: string;
  victimId: string;
  victimName: string;
  color: BeanColor;
  x: number;
  y: number;
  room: RoomId;
  reported: boolean;
}

export interface Vent {
  id: string;
  room: RoomId;
  x: number;
  y: number;
  connectedVentIds: string[];
}

export type SabotageType = 'reactor' | 'o2' | 'lights' | 'none';

export interface SabotageState {
  active: SabotageType;
  countdown: number; // For reactor & o2
  fixProgressA: boolean;
  fixProgressB: boolean;
}

export interface MeetingState {
  reporterName: string;
  cause: 'body' | 'button';
  victimName?: string;
  discussionTimeLeft: number;
  votes: Record<string, string>; // voterId -> targetId | 'skip'
  hasVoted: boolean;
  chatMessages: {
    senderId: string;
    senderName: string;
    color: BeanColor;
    text: string;
    timestamp: number;
  }[];
  ejectedCharacter?: Character | null;
  ejectionText?: string;
  isImpostor?: boolean;
}

export type ConsoleTheme = 'switch' | 'gameboy' | 'famicom' | 'frameless';
