import React, { useEffect } from 'react';
import { SabotageType, SabotageState } from '../types';
import { sound } from '../audio/soundEngine';
import { X, Flame, Wind, Lightbulb, Lock } from 'lucide-react';

interface SabotageModalProps {
  sabotage: SabotageState;
  onTriggerSabotage: (type: SabotageType) => void;
  onClose: () => void;
}

export const SabotageModal: React.FC<SabotageModalProps> = ({
  sabotage,
  onTriggerSabotage,
  onClose,
}) => {
  useEffect(() => {
    sound.trigger('modal_open');
  }, []);

  const handleClose = () => {
    sound.trigger('modal_close');
    onClose();
  };

  const handleSelect = (type: SabotageType) => {
    sound.trigger('sabotage_alert');
    onTriggerSabotage(type);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-lg bg-zinc-950 border-4 border-red-700 rounded-2xl overflow-hidden font-pixel text-zinc-100 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between bg-red-950 px-4 py-3 border-b-2 border-red-700">
          <div className="flex items-center gap-2">
            <Flame className="text-red-500 animate-bounce" size={20} />
            <span className="font-arcade text-xs text-red-400 tracking-wider">
              IMPOSTOR SABOTAGE GRID
            </span>
          </div>
          <button
            onClick={handleClose}
            className="text-zinc-400 hover:text-white p-1 hover:bg-red-900 rounded transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Sabotage selection cards */}
        <div className="p-6 grid grid-cols-2 gap-4 bg-zinc-950">
          {/* Reactor */}
          <button
            onClick={() => handleSelect('reactor')}
            disabled={sabotage.active !== 'none'}
            className="flex flex-col items-center gap-3 p-5 rounded-xl border-2 border-red-900 bg-zinc-900 hover:border-red-500 hover:bg-red-950/40 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
          >
            <div className="w-12 h-12 rounded-full bg-red-900/60 border border-red-500 flex items-center justify-center text-red-400">
              <Flame size={24} />
            </div>
            <div className="text-center">
              <div className="font-arcade text-xs text-red-400">REACTOR</div>
              <div className="text-[10px] text-zinc-400 mt-1">30s Meltdown Alert</div>
            </div>
          </button>

          {/* O2 */}
          <button
            onClick={() => handleSelect('o2')}
            disabled={sabotage.active !== 'none'}
            className="flex flex-col items-center gap-3 p-5 rounded-xl border-2 border-amber-900 bg-zinc-900 hover:border-amber-500 hover:bg-amber-950/40 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
          >
            <div className="w-12 h-12 rounded-full bg-amber-900/60 border border-amber-500 flex items-center justify-center text-amber-400">
              <Wind size={24} />
            </div>
            <div className="text-center">
              <div className="font-arcade text-xs text-amber-400">OXYGEN (O2)</div>
              <div className="text-[10px] text-zinc-400 mt-1">30s Depletion Alert</div>
            </div>
          </button>

          {/* Lights */}
          <button
            onClick={() => handleSelect('lights')}
            disabled={sabotage.active !== 'none'}
            className="flex flex-col items-center gap-3 p-5 rounded-xl border-2 border-blue-900 bg-zinc-900 hover:border-blue-500 hover:bg-blue-950/40 active:scale-95 transition-all cursor-pointer disabled:opacity-50"
          >
            <div className="w-12 h-12 rounded-full bg-blue-900/60 border border-blue-500 flex items-center justify-center text-blue-400">
              <Lightbulb size={24} />
            </div>
            <div className="text-center">
              <div className="font-arcade text-xs text-blue-400">LIGHTS OUT</div>
              <div className="text-[10px] text-zinc-400 mt-1">Dims Crew Vision</div>
            </div>
          </button>

          {/* Doors */}
          <button
            onClick={() => handleSelect('none')}
            className="flex flex-col items-center gap-3 p-5 rounded-xl border-2 border-zinc-800 bg-zinc-900 hover:border-zinc-500 active:scale-95 transition-all cursor-pointer"
          >
            <div className="w-12 h-12 rounded-full bg-zinc-800 border border-zinc-600 flex items-center justify-center text-zinc-300">
              <Lock size={24} />
            </div>
            <div className="text-center">
              <div className="font-arcade text-xs text-zinc-300">DOOR LOCKS</div>
              <div className="text-[10px] text-zinc-500 mt-1">Delay Corridors</div>
            </div>
          </button>
        </div>

        {/* Notice */}
        <div className="px-6 pb-4 text-center font-arcade text-[10px] text-red-400/80">
          WARNING: CREWMATES MUST INTERVENE BEFORE TIME RUNS OUT!
        </div>
      </div>
    </div>
  );
};
