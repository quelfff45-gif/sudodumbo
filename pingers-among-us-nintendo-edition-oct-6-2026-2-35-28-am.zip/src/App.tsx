import React, { useState } from 'react';
import { useGameLogic } from './game/useGameLogic';
import { ConsoleShell } from './components/ConsoleShell';
import { GameCanvas } from './components/GameCanvas';
import { NintendoTitleScreen, RoleRevealScreen } from './components/NintendoTitleScreen';
import { TaskModal } from './components/TaskModal';
import { MeetingModal } from './components/MeetingModal';
import { AdminMapModal } from './components/AdminMapModal';
import { SecurityCamerasModal } from './components/SecurityCamerasModal';
import { SabotageModal } from './components/SabotageModal';
import { CustomizerModal } from './components/CustomizerModal';
import { WorkspaceModal } from './components/WorkspaceModal';
import { StudioIntro } from './components/StudioIntro';
import { CreditsModal } from './components/CreditsModal';
import { ConsoleTheme } from './types';
import { sound } from './audio/soundEngine';
import {
  MapPin,
  Radio,
  Flame,
  AlertTriangle,
  RotateCcw,
  CheckCircle2,
  Circle,
  Video,
  Map as MapIcon,
  Skull,
  Eye,
} from 'lucide-react';

export default function App() {
  const [consoleTheme, setConsoleTheme] = useState<ConsoleTheme>('switch');
  const [isMuted, setIsMuted] = useState(false);
  const [showStudioIntro, setShowStudioIntro] = useState(true);
  const [creditsOpen, setCreditsOpen] = useState(false);

  const {
    status,
    setStatus,
    playerRolePreference,
    setPlayerRolePreference,
    playerColor,
    setPlayerColor,
    playerHat,
    setPlayerHat,
    playerName,
    setPlayerName,
    characters,
    deadBodies,
    player,
    activeTask,
    setActiveTask,
    nearbyTask,
    nearbyVent,
    nearbyBody,
    canEmergency,
    canAccessComms,
    adminMapOpen,
    setAdminMapOpen,
    cctvOpen,
    setCctvOpen,
    sabotageOpen,
    setSabotageOpen,
    customizerOpen,
    setCustomizerOpen,
    workspaceOpen,
    setWorkspaceOpen,
    sabotage,
    triggerSabotage,
    meeting,
    endGameMessage,
    startNewGame,
    handleInteractButton,
    handleKillButton,
    handleReportButton,
    handleVentButton,
    castVote,
    closeMeeting,
    handleCompleteCurrentTask,
    setVirtualKey,
  } = useGameLogic();

  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sound.setMuted(next);
  };

  // Task bar progress calculation
  const allCrewTasks = characters.flatMap((c) => (c.role === 'crewmate' ? c.tasks : []));
  const totalTasks = allCrewTasks.length;
  const completedTasks = allCrewTasks.filter((t) => t.completed).length;
  const taskProgressPct = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  return (
    <ConsoleShell
      theme={consoleTheme}
      onChangeTheme={setConsoleTheme}
      onDPadChange={setVirtualKey}
      onPressA={handleInteractButton}
      onPressB={handleVentButton}
      onPressX={handleReportButton}
      onPressY={handleKillButton}
      onPressSelect={() => setAdminMapOpen((prev) => !prev)}
      onPressStart={() => {
        if (status === 'playing') {
          // Open map or pause
          setAdminMapOpen((prev) => !prev);
        }
      }}
      isMuted={isMuted}
      onToggleMute={handleToggleMute}
      pingMs={player?.pingMs || 22}
      onOpenWorkspace={() => setWorkspaceOpen(true)}
    >
      {/* 0. Studio Intro Screen (Roman James Productions) */}
      {showStudioIntro && (
        <StudioIntro onFinish={() => setShowStudioIntro(false)} />
      )}

      {/* 1. Title Screen */}
      {!showStudioIntro && status === 'title' && (
        <NintendoTitleScreen
          onStartGame={(role) => startNewGame(role)}
          onOpenCustomizer={() => setCustomizerOpen(true)}
          onOpenWorkspace={() => setWorkspaceOpen(true)}
          onOpenCredits={() => setCreditsOpen(true)}
          playerColor={playerColor}
          playerHat={playerHat}
          playerName={playerName}
        />
      )}

      {/* 2. Role Reveal Cutscene */}
      {!showStudioIntro && status === 'role_reveal' && player && (
        <RoleRevealScreen role={player.role} color={player.color} />
      )}

      {/* 3. Main Gameplay & Game Canvas */}
      {!showStudioIntro && (status === 'playing' || status === 'meeting' || status === 'victory' || status === 'defeat') && player && (
        <div className="relative w-full h-full overflow-hidden select-none">
          <GameCanvas
            player={player}
            characters={characters}
            deadBodies={deadBodies}
            tasks={player.tasks}
            sabotage={sabotage}
            nearbyTask={nearbyTask}
            nearbyVent={nearbyVent}
            nearbyBody={nearbyBody}
            canEmergency={canEmergency}
            canAccessComms={canAccessComms}
          />

          {/* In-Game HUD Overlay */}
          <div className="absolute inset-0 pointer-events-none p-3 flex flex-col justify-between">
            {/* Top Bar: Total Tasks Progress Bar & Room HUD */}
            <div className="flex items-start justify-between gap-4">
              {/* Task Progress Bar */}
              <div className="pointer-events-auto bg-zinc-950/85 border-2 border-zinc-700 rounded-lg p-2 max-w-xs sm:max-w-md w-full shadow-lg">
                <div className="flex justify-between items-center text-[9px] font-arcade text-zinc-300 mb-1">
                  <span className="text-emerald-400">TOTAL TASKS COMPLETED</span>
                  <span>{Math.round(taskProgressPct)}%</span>
                </div>
                <div className="w-full h-3 bg-zinc-800 rounded overflow-hidden border border-zinc-700">
                  <div
                    className="h-full bg-emerald-500 transition-all duration-300 shadow-[0_0_8px_#10b981]"
                    style={{ width: `${taskProgressPct}%` }}
                  />
                </div>
              </div>

              {/* Status / Sabotage Banner */}
              <div className="flex flex-col items-end gap-1 pointer-events-auto">
                <div className="bg-zinc-950/85 border border-zinc-700 rounded px-2.5 py-1 text-[9px] font-arcade text-zinc-300 flex items-center gap-1.5 shadow">
                  <MapPin size={12} className="text-amber-400" />
                  <span>ROOM: {player.currentRoom.toUpperCase()}</span>
                </div>

                {sabotage.active !== 'none' && (
                  <div className="bg-red-950/90 border-2 border-red-500 text-red-200 rounded px-3 py-1 text-[9px] font-arcade flex items-center gap-1.5 shadow-lg animate-pulse">
                    <AlertTriangle size={14} className="text-red-400" />
                    <span>
                      {sabotage.active.toUpperCase()} CRITICAL!{' '}
                      {Math.ceil(sabotage.countdown)}s
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Bottom HUD: Tasks Checklist (left) & Touch Action Buttons (right) */}
            <div className="flex items-end justify-between gap-4">
              {/* Task Checklist (for Crewmates and Ghosts) */}
              <div className="pointer-events-auto bg-zinc-950/90 border-2 border-zinc-800 rounded-lg p-3 max-w-xs shadow-xl hidden sm:block">
                <div className="font-arcade text-[9px] text-zinc-400 border-b border-zinc-800 pb-1.5 mb-2">
                  {player.role === 'impostor' ? 'FAKED TASKS (DECEPTION)' : 'CREW DIRECTIVES'}
                </div>
                <div className="space-y-1.5 text-[9px] font-pixel">
                  {player.tasks.map((task) => (
                    <div
                      key={task.id}
                      className={`flex items-center gap-1.5 ${
                        task.completed ? 'text-emerald-400 line-through' : 'text-zinc-200'
                      }`}
                    >
                      {task.completed ? (
                        <CheckCircle2 size={11} className="text-emerald-400 shrink-0" />
                      ) : (
                        <Circle size={11} className="text-amber-400 shrink-0" />
                      )}
                      <span className="truncate">
                        {task.name} ({task.room.split('_')[0]})
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Buttons Toolbar */}
              <div className="pointer-events-auto flex items-center gap-2 sm:gap-3">
                {/* Comms Terminal (Gmail & Forms) */}
                <button
                  onClick={() => setWorkspaceOpen(true)}
                  title="Communications Terminal (Gmail & Google Forms)"
                  className="w-11 h-11 bg-amber-950/70 hover:bg-amber-900 active:scale-95 border-2 border-amber-600 text-amber-300 rounded-xl flex items-center justify-center shadow-lg cursor-pointer"
                >
                  <Radio size={18} className="animate-pulse" />
                </button>

                {/* Gadgets: Admin Map & CCTV Cameras */}
                <button
                  onClick={() => setAdminMapOpen((prev) => !prev)}
                  title="Ship Sensor Map"
                  className="w-11 h-11 bg-zinc-900 hover:bg-zinc-800 active:scale-95 border-2 border-zinc-700 text-zinc-300 rounded-xl flex items-center justify-center shadow-lg cursor-pointer"
                >
                  <MapIcon size={18} />
                </button>

                <button
                  onClick={() => setCctvOpen((prev) => !prev)}
                  title="Security Surveillance Cameras"
                  className="w-11 h-11 bg-zinc-900 hover:bg-zinc-800 active:scale-95 border-2 border-zinc-700 text-zinc-300 rounded-xl flex items-center justify-center shadow-lg cursor-pointer"
                >
                  <Video size={18} />
                </button>

                {/* Impostor Sabotage Trigger Button */}
                {player.role === 'impostor' && (
                  <button
                    onClick={() => setSabotageOpen(true)}
                    className="w-12 h-12 bg-red-950 hover:bg-red-900 active:scale-95 border-2 border-red-600 text-red-300 rounded-xl flex flex-col items-center justify-center shadow-lg cursor-pointer font-arcade text-[8px]"
                  >
                    <Flame size={16} />
                    <span>SAB</span>
                  </button>
                )}

                {/* Impostor Vent Button */}
                {player.role === 'impostor' && (
                  <button
                    onClick={handleVentButton}
                    disabled={!nearbyVent}
                    className={`w-12 h-12 rounded-xl border-2 flex flex-col items-center justify-center shadow-lg font-arcade text-[8px] transition-all cursor-pointer ${
                      nearbyVent
                        ? 'bg-sky-600 hover:bg-sky-500 border-sky-400 text-white animate-pulse'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-600 opacity-50 cursor-not-allowed'
                    }`}
                  >
                    <Eye size={16} />
                    <span>[B] VENT</span>
                  </button>
                )}

                {/* Impostor Kill Button */}
                {player.role === 'impostor' && (
                  <button
                    onClick={handleKillButton}
                    disabled={player.killCooldown > 0}
                    className={`w-14 h-14 rounded-2xl border-2 flex flex-col items-center justify-center shadow-xl font-arcade text-[9px] transition-all cursor-pointer ${
                      player.killCooldown <= 0
                        ? 'bg-red-600 hover:bg-red-500 border-red-400 text-white animate-pulse'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-500 opacity-60 cursor-not-allowed'
                    }`}
                  >
                    <Skull size={18} />
                    <span>{player.killCooldown > 0 ? `${Math.ceil(player.killCooldown)}s` : '[Y] KILL'}</span>
                  </button>
                )}

                {/* Report Dead Body Button */}
                <button
                  onClick={handleReportButton}
                  disabled={!nearbyBody}
                  className={`w-13 h-13 rounded-2xl border-2 flex flex-col items-center justify-center shadow-xl font-arcade text-[8px] transition-all cursor-pointer ${
                    nearbyBody
                      ? 'bg-red-600 hover:bg-red-500 border-red-300 text-white animate-bounce'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-600 opacity-40 cursor-not-allowed'
                  }`}
                >
                  <AlertTriangle size={18} />
                  <span>[X] REPORT</span>
                </button>

                {/* Use / Interact Task Button */}
                <button
                  onClick={handleInteractButton}
                  disabled={!nearbyTask && !canEmergency && !canAccessComms}
                  className={`w-14 h-14 rounded-2xl border-2 flex flex-col items-center justify-center shadow-xl font-arcade text-[9px] transition-all cursor-pointer ${
                    nearbyTask || canEmergency || canAccessComms
                      ? 'bg-emerald-600 hover:bg-emerald-500 border-emerald-300 text-white animate-pulse scale-105'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-600 opacity-40 cursor-not-allowed'
                  }`}
                >
                  <span>[A]</span>
                  <span>{canEmergency ? 'BUTTON' : canAccessComms ? 'COMMS' : 'USE'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. Active Task Minigame Modal */}
      {activeTask && (
        <TaskModal
          task={activeTask}
          onComplete={handleCompleteCurrentTask}
          onClose={() => setActiveTask(null)}
        />
      )}

      {/* 5. Emergency Meeting & Voting Modal */}
      {meeting && status === 'meeting' && (
        <MeetingModal
          characters={characters}
          meeting={meeting}
          onCastVote={castVote}
          onCloseMeeting={closeMeeting}
        />
      )}

      {/* 6. Admin Sensors Map Modal */}
      {adminMapOpen && (
        <AdminMapModal
          characters={characters}
          deadBodies={deadBodies}
          onClose={() => setAdminMapOpen(false)}
        />
      )}

      {/* 7. Security CCTV Cameras Modal */}
      {cctvOpen && (
        <SecurityCamerasModal
          characters={characters}
          onClose={() => setCctvOpen(false)}
        />
      )}

      {/* 8. Impostor Sabotage Map Modal */}
      {sabotageOpen && (
        <SabotageModal
          sabotage={sabotage}
          onTriggerSabotage={triggerSabotage}
          onClose={() => setSabotageOpen(false)}
        />
      )}

      {/* 9. Bean Wardrobe Customizer Modal */}
      {customizerOpen && (
        <CustomizerModal
          currentColor={playerColor}
          currentHat={playerHat}
          playerName={playerName}
          onUpdate={(c, h, n) => {
            setPlayerColor(c);
            setPlayerHat(h);
            setPlayerName(n);
          }}
          onClose={() => setCustomizerOpen(false)}
        />
      )}

      {/* 10. Workspace Communications Modal (Gmail & Google Forms) */}
      {workspaceOpen && (
        <WorkspaceModal onClose={() => setWorkspaceOpen(false)} />
      )}

      {/* 11. Roman James Productions Credits Modal */}
      {creditsOpen && (
        <CreditsModal
          onClose={() => setCreditsOpen(false)}
          onReplayIntro={() => {
            setCreditsOpen(false);
            setShowStudioIntro(true);
          }}
        />
      )}

      {/* 12. Game Over Screen (Victory / Defeat) */}
      {(status === 'victory' || status === 'defeat') && endGameMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-6 font-arcade text-zinc-100">
          <div className="max-w-md w-full bg-zinc-900 border-4 border-zinc-700 rounded-2xl p-6 text-center shadow-2xl flex flex-col items-center">
            <h1
              className={`text-3xl tracking-widest mb-3 ${
                endGameMessage.won ? 'text-emerald-400 drop-shadow-[0_0_15px_#10b981]' : 'text-red-500 drop-shadow-[0_0_15px_#ef4444]'
              }`}
            >
              {endGameMessage.title}
            </h1>
            <p className="font-pixel text-sm text-zinc-300 mb-6">
              {endGameMessage.subtitle}
            </p>

            <div className="flex flex-col gap-3 w-full">
              <button
                onClick={() => startNewGame()}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-arcade rounded border-b-4 border-emerald-900 cursor-pointer uppercase transition-colors"
              >
                [A] PLAY AGAIN
              </button>
              <button
                onClick={() => setStatus('title')}
                className="w-full py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-arcade rounded border border-zinc-700 cursor-pointer uppercase transition-colors"
              >
                MAIN MENU
              </button>
            </div>
          </div>
        </div>
      )}
    </ConsoleShell>
  );
}
