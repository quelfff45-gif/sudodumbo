import React, { useState } from 'react';
import { ConsoleTheme } from '../types';
import { sound } from '../audio/soundEngine';
import {
  Volume2,
  VolumeX,
  Tv,
  Maximize2,
  Minimize2,
  Wifi,
  BatteryCharging,
} from 'lucide-react';

interface ConsoleShellProps {
  theme: ConsoleTheme;
  onChangeTheme: (t: ConsoleTheme) => void;
  onDPadChange: (direction: 'w' | 's' | 'a' | 'd', isPressed: boolean) => void;
  onPressA: () => void;
  onPressB: () => void;
  onPressX: () => void;
  onPressY: () => void;
  onPressSelect: () => void;
  onPressStart: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  pingMs: number;
  onOpenWorkspace?: () => void;
  children: React.ReactNode;
}

export const ConsoleShell: React.FC<ConsoleShellProps> = ({
  theme,
  onChangeTheme,
  onDPadChange,
  onPressA,
  onPressB,
  onPressX,
  onPressY,
  onPressSelect,
  onPressStart,
  isMuted,
  onToggleMute,
  pingMs,
  onOpenWorkspace,
  children,
}) => {
  const [crtEnabled, setCrtEnabled] = useState(true);

  return (
    <div className="w-full h-screen max-h-screen bg-zinc-950 flex flex-col items-center justify-center p-2 sm:p-4 overflow-hidden select-none">
      {/* Top Console Bar */}
      <div className="w-full max-w-6xl flex items-center justify-between px-3 py-1.5 text-zinc-400 font-pixel text-xs border-b border-zinc-800 mb-2">
        <div className="flex items-center gap-3 sm:gap-4">
          <div className="flex items-center gap-1.5 font-arcade text-zinc-200">
            <span className="w-2.5 h-2.5 rounded-sm bg-red-600 animate-pulse" />
            <span className="text-red-500 font-bold">Nintendo</span>
            <span className="text-[10px] text-zinc-400 hidden xs:inline">PINGERS: AMONG US</span>
            <span className="text-[9px] text-amber-400/90 font-pixel hidden md:inline">· ROMAN JAMES PRODUCTIONS</span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-[10px] text-zinc-400">
            <Wifi size={12} className={pingMs < 100 ? 'text-emerald-400' : 'text-amber-400'} />
            <span>PING: {pingMs}ms</span>
          </div>

          {onOpenWorkspace && (
            <button
              onClick={() => {
                sound.playUiClick();
                onOpenWorkspace();
              }}
              className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-950/70 hover:bg-amber-900/80 border border-amber-500/70 text-amber-300 rounded font-arcade text-[9px] cursor-pointer shadow transition-all active:scale-95"
            >
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
              <span>COMMS: GMAIL &amp; FORMS</span>
            </button>
          )}
        </div>

        {/* Theme and Display Switches */}
        <div className="flex items-center gap-2 sm:gap-3 text-xs">
          {/* Theme Selector */}
          <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded p-0.5 text-[9px] font-arcade">
            {(['switch', 'gameboy', 'famicom', 'frameless'] as ConsoleTheme[]).map((t) => (
              <button
                key={t}
                onClick={() => {
                  sound.playUiClick();
                  onChangeTheme(t);
                }}
                className={`px-2 py-1 rounded capitalize transition-colors cursor-pointer ${
                  theme === t ? 'bg-zinc-700 text-white font-bold' : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {t}
              </button>
            ))}
          </div>

          {/* CRT Scanline Toggle */}
          <button
            onClick={() => setCrtEnabled(!crtEnabled)}
            title="Toggle CRT Scanlines"
            className={`p-1.5 rounded border transition-colors cursor-pointer ${
              crtEnabled ? 'border-emerald-500 text-emerald-400 bg-emerald-950/40' : 'border-zinc-800 text-zinc-600'
            }`}
          >
            <Tv size={14} />
          </button>

          {/* Sound Mute */}
          <button
            onClick={onToggleMute}
            className="p-1.5 rounded border border-zinc-800 text-zinc-400 hover:text-white cursor-pointer"
          >
            {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
          </button>
        </div>
      </div>

      {/* Main Console Container */}
      <div className="w-full max-w-6xl flex-1 flex items-center justify-center relative min-h-0">
        {theme === 'switch' && (
          <SwitchLayout
            crtEnabled={crtEnabled}
            onDPadChange={onDPadChange}
            onPressA={onPressA}
            onPressB={onPressB}
            onPressX={onPressX}
            onPressY={onPressY}
            onPressSelect={onPressSelect}
            onPressStart={onPressStart}
          >
            {children}
          </SwitchLayout>
        )}

        {theme === 'gameboy' && (
          <GameBoyLayout
            crtEnabled={crtEnabled}
            onDPadChange={onDPadChange}
            onPressA={onPressA}
            onPressB={onPressB}
            onPressX={onPressX}
            onPressY={onPressY}
            onPressSelect={onPressSelect}
            onPressStart={onPressStart}
          >
            {children}
          </GameBoyLayout>
        )}

        {theme === 'famicom' && (
          <FamicomLayout
            crtEnabled={crtEnabled}
            onDPadChange={onDPadChange}
            onPressA={onPressA}
            onPressB={onPressB}
            onPressX={onPressX}
            onPressY={onPressY}
            onPressSelect={onPressSelect}
            onPressStart={onPressStart}
          >
            {children}
          </FamicomLayout>
        )}

        {theme === 'frameless' && (
          <div className="relative w-full h-full flex flex-col bg-black rounded-lg overflow-hidden border border-zinc-800 shadow-2xl">
            <div className={`relative flex-1 w-full h-full overflow-hidden ${crtEnabled ? 'crt-scanlines' : ''}`}>
              {children}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

/**
 * 1. NINTENDO SWITCH HARDWARE CASING
 */
const SwitchLayout: React.FC<{
  crtEnabled: boolean;
  onDPadChange: (direction: 'w' | 's' | 'a' | 'd', isPressed: boolean) => void;
  onPressA: () => void;
  onPressB: () => void;
  onPressX: () => void;
  onPressY: () => void;
  onPressSelect: () => void;
  onPressStart: () => void;
  children: React.ReactNode;
}> = ({
  crtEnabled,
  onDPadChange,
  onPressA,
  onPressB,
  onPressX,
  onPressY,
  onPressSelect,
  onPressStart,
  children,
}) => {
  return (
    <div className="flex items-center justify-center w-full h-full max-h-[780px]">
      {/* Left Joy-Con (Neon Blue) */}
      <div className="hidden lg:flex w-24 h-full max-h-[640px] bg-sky-500 rounded-l-3xl p-3 flex-col justify-between items-center shadow-xl border-t-2 border-l-2 border-b-2 border-sky-400/40 relative">
        {/* Minus Button */}
        <button
          onClick={onPressSelect}
          className="w-5 h-2 bg-zinc-800 rounded-sm hover:bg-zinc-700 active:scale-90 cursor-pointer shadow"
        />

        {/* Left Analog Stick */}
        <div className="w-14 h-14 rounded-full bg-zinc-900 border-4 border-zinc-700 shadow-inner flex items-center justify-center">
          <div className="w-10 h-10 rounded-full bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-zinc-950" />
          </div>
        </div>

        {/* Directional D-Pad Buttons */}
        <div className="relative w-16 h-16 flex items-center justify-center">
          {/* UP */}
          <button
            onMouseDown={() => onDPadChange('w', true)}
            onMouseUp={() => onDPadChange('w', false)}
            onTouchStart={() => onDPadChange('w', true)}
            onTouchEnd={() => onDPadChange('w', false)}
            className="absolute top-0 w-5 h-5 rounded-full bg-zinc-900 text-zinc-400 font-pixel text-[8px] flex items-center justify-center hover:bg-zinc-800 active:scale-90 shadow"
          >
            ▲
          </button>
          {/* DOWN */}
          <button
            onMouseDown={() => onDPadChange('s', true)}
            onMouseUp={() => onDPadChange('s', false)}
            onTouchStart={() => onDPadChange('s', true)}
            onTouchEnd={() => onDPadChange('s', false)}
            className="absolute bottom-0 w-5 h-5 rounded-full bg-zinc-900 text-zinc-400 font-pixel text-[8px] flex items-center justify-center hover:bg-zinc-800 active:scale-90 shadow"
          >
            ▼
          </button>
          {/* LEFT */}
          <button
            onMouseDown={() => onDPadChange('a', true)}
            onMouseUp={() => onDPadChange('a', false)}
            onTouchStart={() => onDPadChange('a', true)}
            onTouchEnd={() => onDPadChange('a', false)}
            className="absolute left-0 w-5 h-5 rounded-full bg-zinc-900 text-zinc-400 font-pixel text-[8px] flex items-center justify-center hover:bg-zinc-800 active:scale-90 shadow"
          >
            ◀
          </button>
          {/* RIGHT */}
          <button
            onMouseDown={() => onDPadChange('d', true)}
            onMouseUp={() => onDPadChange('d', false)}
            onTouchStart={() => onDPadChange('d', true)}
            onTouchEnd={() => onDPadChange('d', false)}
            className="absolute right-0 w-5 h-5 rounded-full bg-zinc-900 text-zinc-400 font-pixel text-[8px] flex items-center justify-center hover:bg-zinc-800 active:scale-90 shadow"
          >
            ▶
          </button>
        </div>

        {/* Capture Square Button */}
        <div className="w-4 h-4 rounded-sm bg-zinc-800 border border-zinc-700" />
      </div>

      {/* Screen Bezel */}
      <div className="flex-1 h-full max-h-[640px] bg-zinc-900 border-4 border-zinc-950 p-2 sm:p-4 flex flex-col rounded-xl shadow-2xl relative min-w-0">
        <div className={`relative flex-1 w-full h-full bg-black rounded-lg overflow-hidden border-2 border-zinc-800 ${crtEnabled ? 'crt-scanlines' : ''}`}>
          {children}
        </div>
      </div>

      {/* Right Joy-Con (Neon Red) */}
      <div className="hidden lg:flex w-24 h-full max-h-[640px] bg-rose-500 rounded-r-3xl p-3 flex-col justify-between items-center shadow-xl border-t-2 border-r-2 border-b-2 border-rose-400/40 relative">
        {/* Plus Button */}
        <button
          onClick={onPressStart}
          className="text-zinc-900 font-bold text-sm hover:scale-110 active:scale-90 cursor-pointer"
        >
          ＋
        </button>

        {/* Action Buttons (A, B, X, Y) */}
        <div className="relative w-16 h-16 flex items-center justify-center font-arcade">
          {/* X (Top) */}
          <button
            onClick={onPressX}
            className="absolute top-0 w-5 h-5 rounded-full bg-zinc-900 text-zinc-200 text-[8px] flex items-center justify-center hover:bg-zinc-800 active:scale-90 shadow border border-zinc-700 cursor-pointer"
          >
            X
          </button>
          {/* B (Bottom) */}
          <button
            onClick={onPressB}
            className="absolute bottom-0 w-5 h-5 rounded-full bg-zinc-900 text-zinc-200 text-[8px] flex items-center justify-center hover:bg-zinc-800 active:scale-90 shadow border border-zinc-700 cursor-pointer"
          >
            B
          </button>
          {/* Y (Left) */}
          <button
            onClick={onPressY}
            className="absolute left-0 w-5 h-5 rounded-full bg-zinc-900 text-zinc-200 text-[8px] flex items-center justify-center hover:bg-zinc-800 active:scale-90 shadow border border-zinc-700 cursor-pointer"
          >
            Y
          </button>
          {/* A (Right) */}
          <button
            onClick={onPressA}
            className="absolute right-0 w-5 h-5 rounded-full bg-zinc-900 text-zinc-200 text-[8px] flex items-center justify-center hover:bg-zinc-800 active:scale-90 shadow border border-zinc-700 cursor-pointer"
          >
            A
          </button>
        </div>

        {/* Right Analog Stick */}
        <div className="w-14 h-14 rounded-full bg-zinc-900 border-4 border-zinc-700 shadow-inner flex items-center justify-center">
          <div className="w-10 h-10 rounded-full bg-zinc-800 border-2 border-zinc-600 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-zinc-950" />
          </div>
        </div>

        {/* Home Button */}
        <div className="w-4 h-4 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center">
          <div className="w-2 h-2 rounded-full bg-zinc-600" />
        </div>
      </div>
    </div>
  );
};

/**
 * 2. GAME BOY COLOR / DMG RETRO HOUSING
 */
const GameBoyLayout: React.FC<{
  crtEnabled: boolean;
  onDPadChange: (direction: 'w' | 's' | 'a' | 'd', isPressed: boolean) => void;
  onPressA: () => void;
  onPressB: () => void;
  onPressX: () => void;
  onPressY: () => void;
  onPressSelect: () => void;
  onPressStart: () => void;
  children: React.ReactNode;
}> = ({
  crtEnabled,
  onDPadChange,
  onPressA,
  onPressB,
  onPressSelect,
  onPressStart,
  children,
}) => {
  return (
    <div className="w-full max-w-4xl h-full flex flex-col bg-purple-900/90 border-4 border-purple-950 rounded-3xl p-4 shadow-2xl">
      {/* Top Game Boy Header */}
      <div className="flex items-center justify-between text-zinc-300 font-pixel text-xs px-2 mb-2">
        <span className="font-arcade text-purple-300 text-[10px]">GAME BOY COLOR</span>
        <span className="text-[9px] text-purple-400">STEREO SOUND</span>
      </div>

      {/* Screen Frame */}
      <div className="flex-1 w-full bg-zinc-800 border-4 border-zinc-950 rounded-xl p-3 flex flex-col overflow-hidden">
        <div className={`relative flex-1 w-full h-full bg-black rounded border-2 border-zinc-900 overflow-hidden ${crtEnabled ? 'crt-scanlines' : ''}`}>
          {children}
        </div>
      </div>

      {/* Bottom Retro Controls (Desktop / Mobile Friendly) */}
      <div className="flex items-center justify-between px-6 pt-3">
        {/* Classic Cross D-Pad */}
        <div className="relative w-20 h-20 flex items-center justify-center">
          <button
            onMouseDown={() => onDPadChange('w', true)}
            onMouseUp={() => onDPadChange('w', false)}
            onTouchStart={() => onDPadChange('w', true)}
            onTouchEnd={() => onDPadChange('w', false)}
            className="absolute top-0 w-7 h-7 bg-zinc-900 text-zinc-400 font-pixel text-xs rounded-t flex items-center justify-center hover:bg-zinc-800 active:scale-95 cursor-pointer shadow"
          >
            ▲
          </button>
          <button
            onMouseDown={() => onDPadChange('s', true)}
            onMouseUp={() => onDPadChange('s', false)}
            onTouchStart={() => onDPadChange('s', true)}
            onTouchEnd={() => onDPadChange('s', false)}
            className="absolute bottom-0 w-7 h-7 bg-zinc-900 text-zinc-400 font-pixel text-xs rounded-b flex items-center justify-center hover:bg-zinc-800 active:scale-95 cursor-pointer shadow"
          >
            ▼
          </button>
          <button
            onMouseDown={() => onDPadChange('a', true)}
            onMouseUp={() => onDPadChange('a', false)}
            onTouchStart={() => onDPadChange('a', true)}
            onTouchEnd={() => onDPadChange('a', false)}
            className="absolute left-0 w-7 h-7 bg-zinc-900 text-zinc-400 font-pixel text-xs rounded-l flex items-center justify-center hover:bg-zinc-800 active:scale-95 cursor-pointer shadow"
          >
            ◀
          </button>
          <button
            onMouseDown={() => onDPadChange('d', true)}
            onMouseUp={() => onDPadChange('d', false)}
            onTouchStart={() => onDPadChange('d', true)}
            onTouchEnd={() => onDPadChange('d', false)}
            className="absolute right-0 w-7 h-7 bg-zinc-900 text-zinc-400 font-pixel text-xs rounded-r flex items-center justify-center hover:bg-zinc-800 active:scale-95 cursor-pointer shadow"
          >
            ▶
          </button>
        </div>

        {/* Select & Start Pill buttons */}
        <div className="flex gap-4 items-center">
          <div className="flex flex-col items-center">
            <button
              onClick={onPressSelect}
              className="w-10 h-3 bg-zinc-800 -rotate-25 rounded-full hover:bg-zinc-700 active:scale-90 cursor-pointer shadow"
            />
            <span className="font-arcade text-[8px] text-purple-300 mt-2">SELECT</span>
          </div>
          <div className="flex flex-col items-center">
            <button
              onClick={onPressStart}
              className="w-10 h-3 bg-zinc-800 -rotate-25 rounded-full hover:bg-zinc-700 active:scale-90 cursor-pointer shadow"
            />
            <span className="font-arcade text-[8px] text-purple-300 mt-2">START</span>
          </div>
        </div>

        {/* Maroon Angled B and A Buttons */}
        <div className="flex gap-4 -rotate-25 items-center">
          <div className="flex flex-col items-center">
            <button
              onClick={onPressB}
              className="w-10 h-10 rounded-full bg-rose-700 text-white font-arcade text-xs flex items-center justify-center hover:bg-rose-600 active:scale-90 shadow-lg border-2 border-rose-950 cursor-pointer"
            >
              B
            </button>
          </div>
          <div className="flex flex-col items-center">
            <button
              onClick={onPressA}
              className="w-10 h-10 rounded-full bg-rose-700 text-white font-arcade text-xs flex items-center justify-center hover:bg-rose-600 active:scale-90 shadow-lg border-2 border-rose-950 cursor-pointer"
            >
              A
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

/**
 * 3. FAMICOM / NES 8-BIT CLASSIC HOUSING
 */
const FamicomLayout: React.FC<{
  crtEnabled: boolean;
  onDPadChange: (direction: 'w' | 's' | 'a' | 'd', isPressed: boolean) => void;
  onPressA: () => void;
  onPressB: () => void;
  onPressX: () => void;
  onPressY: () => void;
  onPressSelect: () => void;
  onPressStart: () => void;
  children: React.ReactNode;
}> = ({
  crtEnabled,
  onDPadChange,
  onPressA,
  onPressB,
  onPressSelect,
  onPressStart,
  children,
}) => {
  return (
    <div className="w-full max-w-4xl h-full flex flex-col bg-amber-100 border-4 border-red-900 rounded-2xl p-4 shadow-2xl text-zinc-900">
      {/* Gold & Red Header */}
      <div className="flex items-center justify-between px-3 py-1 bg-red-800 text-amber-200 rounded font-arcade text-xs mb-2 border border-red-950">
        <span>FAMICOM FAMILY COMPUTER</span>
        <span className="text-[10px]">PINGERS EDITION</span>
      </div>

      <div className={`relative flex-1 w-full h-full bg-black rounded-lg overflow-hidden border-4 border-zinc-900 ${crtEnabled ? 'crt-scanlines famicom-palette' : ''}`}>
        {children}
      </div>

      {/* Controller Strip */}
      <div className="flex items-center justify-between px-6 pt-3 bg-red-900/10 rounded-b-xl">
        <div className="relative w-16 h-16 flex items-center justify-center">
          <button
            onMouseDown={() => onDPadChange('w', true)}
            onMouseUp={() => onDPadChange('w', false)}
            className="absolute top-0 w-5 h-5 bg-black text-white text-[8px] flex items-center justify-center rounded"
          >
            ▲
          </button>
          <button
            onMouseDown={() => onDPadChange('s', true)}
            onMouseUp={() => onDPadChange('s', false)}
            className="absolute bottom-0 w-5 h-5 bg-black text-white text-[8px] flex items-center justify-center rounded"
          >
            ▼
          </button>
          <button
            onMouseDown={() => onDPadChange('a', true)}
            onMouseUp={() => onDPadChange('a', false)}
            className="absolute left-0 w-5 h-5 bg-black text-white text-[8px] flex items-center justify-center rounded"
          >
            ◀
          </button>
          <button
            onMouseDown={() => onDPadChange('d', true)}
            onMouseUp={() => onDPadChange('d', false)}
            className="absolute right-0 w-5 h-5 bg-black text-white text-[8px] flex items-center justify-center rounded"
          >
            ▶
          </button>
        </div>

        <div className="flex gap-4">
          <button onClick={onPressSelect} className="font-arcade text-[9px] bg-zinc-800 text-white px-3 py-1 rounded">
            SELECT
          </button>
          <button onClick={onPressStart} className="font-arcade text-[9px] bg-zinc-800 text-white px-3 py-1 rounded">
            START
          </button>
        </div>

        <div className="flex gap-4">
          <button onClick={onPressB} className="w-8 h-8 rounded-full bg-red-700 text-white font-arcade text-xs">
            B
          </button>
          <button onClick={onPressA} className="w-8 h-8 rounded-full bg-red-700 text-white font-arcade text-xs">
            A
          </button>
        </div>
      </div>
    </div>
  );
};
