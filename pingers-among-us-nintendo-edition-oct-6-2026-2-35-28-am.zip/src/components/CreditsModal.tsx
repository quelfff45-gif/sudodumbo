import React from 'react';
import { X, Award, Star, Heart, Film } from 'lucide-react';
import { sound } from '../audio/soundEngine';

interface CreditsModalProps {
  onClose: () => void;
  onReplayIntro: () => void;
}

export const CreditsModal: React.FC<CreditsModalProps> = ({ onClose, onReplayIntro }) => {
  React.useEffect(() => {
    sound.trigger('modal_open');
  }, []);

  const handleClose = () => {
    sound.trigger('modal_close');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 font-pixel select-none text-zinc-100">
      <div className="relative w-full max-w-lg bg-zinc-950 border-4 border-amber-500 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-zinc-900 px-4 py-3 border-b-2 border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="text-amber-400" size={18} />
            <span className="font-arcade text-xs text-amber-400 tracking-wider">
              PRODUCTION CREDITS
            </span>
          </div>
          <button
            onClick={handleClose}
            className="text-zinc-400 hover:text-white p-1 hover:bg-zinc-800 rounded transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Credits Body */}
        <div className="p-6 text-center space-y-6 bg-zinc-950 overflow-y-auto max-h-[70vh]">
          {/* Studio Banner */}
          <div className="space-y-1">
            <div className="text-[10px] text-amber-400 font-pixel tracking-widest">
              PRODUCED &amp; PUBLISHED BY
            </div>
            <h2 className="font-arcade text-base sm:text-lg text-amber-300 tracking-wider">
              ROMAN JAMES PRODUCTIONS
            </h2>
            <div className="flex justify-center gap-1 text-amber-400 pt-1">
              <Star size={12} className="fill-amber-400" />
              <Star size={12} className="fill-amber-400" />
              <Star size={12} className="fill-amber-400" />
              <Star size={12} className="fill-amber-400" />
              <Star size={12} className="fill-amber-400" />
            </div>
          </div>

          {/* Credits List */}
          <div className="grid grid-cols-1 gap-3 text-xs bg-zinc-900/60 p-4 rounded-xl border border-zinc-800">
            <div>
              <div className="text-[9px] text-zinc-500 font-arcade uppercase">Executive Producer</div>
              <div className="font-arcade text-zinc-200 mt-0.5">Roman James Productions</div>
            </div>

            <div>
              <div className="text-[9px] text-zinc-500 font-arcade uppercase">Game Concept &amp; Direction</div>
              <div className="font-arcade text-amber-400 mt-0.5">Roman James</div>
            </div>

            <div>
              <div className="text-[9px] text-zinc-500 font-arcade uppercase">Nintendo Edition Architecture</div>
              <div className="font-arcade text-zinc-200 mt-0.5">Chiptune &amp; Pixel Engine</div>
            </div>

            <div>
              <div className="text-[9px] text-zinc-500 font-arcade uppercase">Workspace Relay</div>
              <div className="font-arcade text-zinc-300 mt-0.5">Gmail &amp; Google Forms Satellite Link</div>
            </div>
          </div>

          <p className="text-[10px] text-zinc-400 leading-relaxed font-pixel max-w-sm mx-auto">
            PINGERS: AMONG US — NINTENDO HARDWARE EDITION is an authentic retro space social deduction game presented by Roman James Productions.
          </p>

          <div className="pt-2 flex flex-col sm:flex-row gap-2 justify-center font-arcade text-[10px]">
            <button
              onClick={() => {
                onClose();
                onReplayIntro();
              }}
              className="flex items-center justify-center gap-1.5 px-4 py-2 bg-amber-950/80 hover:bg-amber-900 text-amber-300 rounded border border-amber-500/60 cursor-pointer"
            >
              <Film size={12} />
              <span>REPLAY STUDIO INTRO</span>
            </button>
            <button
              onClick={onClose}
              className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded cursor-pointer"
            >
              CLOSE
            </button>
          </div>
        </div>

        {/* Footer */}
        <div className="bg-zinc-900 px-4 py-2 border-t border-zinc-800 text-center text-[8px] text-zinc-500 font-arcade">
          © 2026 ROMAN JAMES PRODUCTIONS · ALL RIGHTS RESERVED
        </div>
      </div>
    </div>
  );
};
