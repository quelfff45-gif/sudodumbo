import { getAccessToken } from './auth';

export interface GmailMessageSummary {
  id: string;
  threadId: string;
  snippet?: string;
  from?: string;
  to?: string;
  subject?: string;
  date?: string;
  unread?: boolean;
}

export interface GmailFullMessage extends GmailMessageSummary {
  bodyText?: string;
}

export async function listGmailMessages(maxResults = 10, query = ''): Promise<GmailMessageSummary[]> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated. Please sign in with Google.');

  const params = new URLSearchParams({
    maxResults: maxResults.toString(),
  });
  if (query) {
    params.set('q', query);
  }

  const res = await fetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages?${params.toString()}`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to fetch messages (${res.status})`);
  }

  const data = await res.json();
  const rawList: { id: string; threadId: string }[] = data.messages || [];

  // Fetch headers for each message concurrently
  const summaries = await Promise.all(
    rawList.slice(0, maxResults).map(async (item) => {
      try {
        const detailRes = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${item.id}?format=metadata&metadataHeaders=From&metadataHeaders=Subject&metadataHeaders=Date&metadataHeaders=To`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        if (!detailRes.ok) {
          return { id: item.id, threadId: item.threadId, snippet: 'Transmission encrypted' };
        }
        const detail = await detailRes.json();
        const headers: { name: string; value: string }[] = detail.payload?.headers || [];

        const getHeader = (name: string) =>
          headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value || '';

        const isUnread = (detail.labelIds || []).includes('UNREAD');

        return {
          id: item.id,
          threadId: item.threadId,
          snippet: detail.snippet || '',
          from: getHeader('From'),
          to: getHeader('To'),
          subject: getHeader('Subject') || '(No Subject)',
          date: getHeader('Date'),
          unread: isUnread,
        };
      } catch {
        return { id: item.id, threadId: item.threadId, snippet: 'Signal received' };
      }
    })
  );

  return summaries;
}

export async function getGmailMessage(id: string): Promise<GmailFullMessage> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated.');

  const res = await fetch(
    `https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}?format=full`,
    {
      headers: { Authorization: `Bearer ${token}` },
    }
  );

  if (!res.ok) {
    throw new Error(`Failed to load transmission detail (${res.status})`);
  }

  const data = await res.json();
  const headers: { name: string; value: string }[] = data.payload?.headers || [];
  const getHeader = (name: string) =>
    headers.find((h) => h.name.toLowerCase() === name.toLowerCase())?.value || '';

  // Extract body text
  let bodyText = data.snippet || '';
  if (data.payload?.parts) {
    const textPart = data.payload.parts.find((p: any) => p.mimeType === 'text/plain');
    if (textPart?.body?.data) {
      bodyText = decodeBase64Url(textPart.body.data);
    }
  } else if (data.payload?.body?.data) {
    bodyText = decodeBase64Url(data.payload.body.data);
  }

  return {
    id: data.id,
    threadId: data.threadId,
    snippet: data.snippet,
    from: getHeader('From'),
    to: getHeader('To'),
    subject: getHeader('Subject') || '(No Subject)',
    date: getHeader('Date'),
    bodyText,
    unread: (data.labelIds || []).includes('UNREAD'),
  };
}

export async function sendGmailMessage(to: string, subject: string, body: string): Promise<void> {
  const token = await getAccessToken();
  if (!token) throw new Error('Not authenticated.');

  const emailLines = [
    `To: ${to}`,
    `Subject: ${subject}`,
    'Content-Type: text/plain; charset=utf-8',
    'MIME-Version: 1.0',
    '',
    body,
  ];
  const emailRaw = emailLines.join('\r\n');

  // URL-safe base64 encoding
  const encodedEmail = btoa(unescape(encodeURIComponent(emailRaw)))
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ raw: encodedEmail }),
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData?.error?.message || `Failed to transmit dispatch (${res.status})`);
  }
}

function decodeBase64Url(input: string): string {
  try {
    const base64 = input.replace(/-/g, '+').replace(/_/g, '/');
    return decodeURIComponent(escape(atob(base64)));
  } catch {
    return input;
  }
}
