import React, { useEffect } from 'react';
import { Character, DeadBody } from '../types';
import { ROOMS } from '../game/mapData';
import { sound } from '../audio/soundEngine';
import { X, Users, Radar } from 'lucide-react';

interface AdminMapModalProps {
  characters: Character[];
  deadBodies: DeadBody[];
  onClose: () => void;
}

export const AdminMapModal: React.FC<AdminMapModalProps> = ({
  characters,
  deadBodies,
  onClose,
}) => {
  useEffect(() => {
    sound.trigger('modal_open');
  }, []);

  const handleClose = () => {
    sound.trigger('modal_close');
    onClose();
  };

  // Count alive characters per room
  const roomCounts: Record<string, number> = {};
  characters.forEach((char) => {
    if (char.state !== 'dead' && char.state !== 'ghost') {
      roomCounts[char.currentRoom] = (roomCounts[char.currentRoom] || 0) + 1;
    }
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-3xl bg-zinc-950 border-4 border-emerald-600 rounded-xl overflow-hidden font-pixel text-zinc-100 shadow-2xl">
        {/* Top header */}
        <div className="flex items-center justify-between bg-zinc-900 px-4 py-3 border-b-2 border-emerald-600">
          <div className="flex items-center gap-2">
            <Radar className="text-emerald-400 animate-spin" size={18} />
            <span className="font-arcade text-xs text-emerald-400 tracking-wider">
              ADMINISTRATIVE SHIP SENSORS (RADAR)
            </span>
          </div>
          <button
            onClick={handleClose}
            className="text-zinc-400 hover:text-white p-1 hover:bg-zinc-800 rounded transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Map schematic */}
        <div className="p-6 relative bg-zinc-950 flex flex-col items-center">
          <div className="relative w-full max-w-2xl h-[380px] bg-zinc-900/90 border-2 border-emerald-800 rounded-xl p-4 overflow-hidden">
            {/* Grid overlay */}
            <div className="absolute inset-0 bg-[linear-gradient(rgba(16,185,129,0.06)_1px,transparent_1px),linear-gradient(90deg,rgba(16,185,129,0.06)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />

            {/* Room boxes */}
            {ROOMS.map((room) => {
              const count = roomCounts[room.id] || 0;
              // Scale coordinates to fit the 600x340 container
              const scaleX = 600 / 2200;
              const scaleY = 340 / 1500;
              const left = (room.x - 100) * scaleX + 20;
              const top = (room.y - 120) * scaleY + 20;
              const width = Math.max(50, room.w * scaleX);
              const height = Math.max(35, room.h * scaleY);

              return (
                <div
                  key={room.id}
                  style={{ left: `${left}px`, top: `${top}px`, width: `${width}px`, height: `${height}px` }}
                  className={`absolute rounded border flex flex-col items-center justify-center p-1 transition-all ${
                    count > 0
                      ? 'bg-emerald-950/80 border-emerald-400 shadow-[0_0_10px_rgba(16,185,129,0.3)]'
                      : 'bg-zinc-950/80 border-zinc-800'
                  }`}
                >
                  <span className="text-[8px] font-arcade text-zinc-300 text-center leading-tight truncate w-full">
                    {room.name.split(' ')[0]}
                  </span>
                  {count > 0 && (
                    <div className="flex items-center gap-1 mt-1">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-[10px] font-arcade text-emerald-300">
                        {count}
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="w-full mt-4 flex items-center justify-between text-xs text-zinc-400 font-arcade">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
              <span>CREWMATE SENSORS ACTIVE</span>
            </div>
            <span>TOTAL BEANS TRACKED: {characters.filter(c => c.state !== 'dead' && c.state !== 'ghost').length}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
